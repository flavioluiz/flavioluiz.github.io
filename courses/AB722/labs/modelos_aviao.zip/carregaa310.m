function p = carregaa310
    %%Dados da Aeronave%%
    % Modelo Aerodinamico %
    % Polar de Arrasto:
    p.CD0 = 0.0175; p.k1 = 0; p.k2 = 0.06;
    % Coeficiente de sustentacao:
    p.CL0 = 0.0; p.CLalpha = 4.982; p.CLq = -0.7/2; p.CLalphap = -0.3/2; p.CLdp = 0.435;
    % Coeficiente de momento de arfagem:
    p.Cm0=-0.025; p.Cmalpha=-1.246; p.Cmq=-15/2; p.Cmalphap=-5/2; p.Cmdp=-1.46;
    % Coeficientes de forca lateral
    p.Cyb=-1.5; p.Cyp=0; p.Cyr=0; p.Cyda=0.05; p.Cydr=0.3; p.Cybp=0;
    % Coeficientes de momento de rolamento
    p.Clb=-1.3; p.Clp=-13/2; p.Clr=2.9/2; p.Clda=-0.33; p.Cldr=0.25; p.Clbp=0;
    % Coeficientes de momento de guinada
    p.Cnb=1.75; p.Cnp=-1.5/2; p.Cnr=-7.5/2; p.Cnda=-0.125; p.Cndr=-1; p.Cnbp=0;
    
    p.Vref = 250; % (m/s) velocidade de referencia
    p.c = 6.61; % (m) corda media aerodinamica:C_ref
    p.b= 6.61; % (m) comprimento de ref.
    p.S = 260; % (m^2) area de referencia
    p.Iyy = 9.72e6; p.Ixx=5.55e6; p.Izz=14.51e6; p.Ixz=-3.3e4;
    p.m=120000; %kg
    
    %dados do modelo propulsivo 
    p.Tmax0 = 240000; %N
    p.rho0 = 1.225; %kg/m^3
    p.V0 = 250; %m/s
    p.nv = 0;
    p.nrho = 1;
    p.alphaF = -2*pi/180;
    p.betaf = 0;
    p.zf =  2;
    p.xf = 0.5;
    p.yf = 0;
end