function p = carregamirage
    %%Dados da Aeronave%%
    % Modelo Aerodinamico %
    % Polar de Arrasto:
    p.CD0 = 0.015; p.k1 = 0; p.k2 = 0.4;
    % Coeficiente de sustentacao:
    p.CL0 = 0.0; p.CLalpha = 2.204; p.CLq = 0; p.CLalphap = 0; p.CLdp = 0.7;
    % Coeficiente de momento de arfagem:
    p.Cm0=0; p.Cmalpha=-0.17; p.Cmq=-0.4/2; p.Cmalphap=-0.45/2; p.Cmdp=-0.45;
    % Coeficientes de forca lateral
    p.Cyb=-0.6; p.Cyp=0; p.Cyr=0; p.Cyda=0.01; p.Cydr=0.075; p.Cybp=0;
    % Coeficientes de momento de rolamento
    p.Clb=-0.05; p.Clp=-0.25/2; p.Clr=0.06/2; p.Clda=-0.30; p.Cldr=0.018; p.Clbp=0;
    % Coeficientes de momento de guinada
    p.Cnb=0.15; p.Cnp=0.055/2; p.Cnr=-0.7/2; p.Cnda=0; p.Cndr=-0.085; p.Cnbp=0;
    
    p.Vref = 250; % (m/s) velocidade de referencia
    p.c = 5.25; % (m) corda media aerodinamica:C_ref
    p.b= 5.25; % (m) comprimento de referencia
    p.S = 36; % (m^2) area de referencia
    p.Iyy = 5.4e4; p.Ixx=0.9e4; p.Izz=6e4; p.Ixz=1.8e3;
    p.m=7400; %kg
    
    %dados do modelo propulsivo 
    p.Tmax0 = 40000; %N
    p.rho0 = 1.225; %kg/m^3
    p.V0 = 100; %m/s
    p.nv = 0;
    p.nrho = 1;
    p.alphaF = 0;
    p.betaf = 0;
    p.zf =  0;
    p.xf = 0;
    p.yf = 0;
end