function Cm = coefmomarf(a,dp,q,ap, params)
Cm = params.Cm0+params.Cmalpha*a+params.Cmdp*dp+(params.Cmq*q+params.Cmalphap*ap)*params.c/params.Vref;
cmtr = 0.17;

if Cm < -cmtr
    Cm = Cm + 4*(Cm + cmtr);
end

if Cm > cmtr
    Cm = Cm + 4*(Cm - cmtr);
end