%......................Equa�oes.no.equilibrio...........................
function F=equilibriofi(y, condicaovoo, params)
        Ve = condicaovoo(1);
        He = condicaovoo(2);
        fi = condicaovoo(3);
        omega = condicaovoo(4);

        d=y(1); a=y(2); b=y(3); teta=y(4);
        dp=y(5); da=y(6); dr=y(7);

        pe=-omega*sin(teta); 
        qe=omega*cos(teta)*sin(fi);
        re=omega*cos(teta)*cos(fi);

        uu=Ve*cos(a)*cos(b);
        v=Ve*sin(b);
        w=Ve*cos(b)*sin(a);


        xe = [uu v w pe qe re fi teta 0 0 0 He];
        ue = [d,dp,da,dr];

        Xp = dinamicacorpo(0,xe,ue,params);

        F=[Xp(1)% up
           Xp(2)% vp   
           Xp(3)% wp
            Xp(4) %pp
            Xp(5) %qp
            Xp(6) %rp
            Xp(12)]; %Hp
end