function p = carregavant
    %%Dados da Aeronave%%
   
    % Modelo Aerodinamico %
    % Polar de Arrasto:
    p.CD0 = 0.0800; p.k1 = -0.0629; p.k2 = 0.0985;
    % Coeficiente de sustentacao:
    p.CL0 = 3.606e-1; p.CLalpha = 4.8677; p.CLq = 6.2875/2; p.CLalphap = 1.5015/2; p.CLdp = 4.424e-1;
    % Coeficiente de momento de arfagem:
    p.Cm0=-6.2e-3; p.Cmalpha=-9.402e-1; p.Cmq=-1.71542e1/2; p.Cmalphap=-5.2681/2; p.Cmdp=-1.5521;
    % Coeficientes de forca lateral
    p.Cyb=-1.305e-1; p.Cyp=0; p.Cyr=1.187e-1/2; p.Cyda=0; p.Cydr=9.68e-2; p.Cybp=0;
    % Coeficientes de momento de rolamento
    p.Clb=-6.84e-2; p.Clp=-4.659e-1/2; p.Clr=1.166e-1/2; p.Clda=-1.67e-1; p.Cldr=1.28e-2; p.Clbp=0;
    % Coeficientes de momento de guinada
    p.Cnb=3.99e-2; p.Cnp=-3.84e-2; p.Cnr=-5.79e-2; p.Cnda=1.09e-2; p.Cndr=-5.01e-2; p.Cnbp=0;
    
    p.Vref = 33; % (m/s) velocidade de referencia
    p.c = 3.55e-1; % (m) corda media aerodinamica:C_ref
    p.b= 2.486; % (m) envergadura da asa
    p.S = 8.83e-1; % (m^2) area de referencia
    p.Iyy = 3.881; p.Ixx=1.05; p.Izz=4.512; p.Ixz=1.497e-1;
    p.m=20; %kg
    
    %dados do modelo propulsivo 
    p.Tmax0 = 43.4145; %N
    p.rho0 = 1.225; %kg/m^3
    p.V0 = 33; %m/s
    p.nv = -1;
    p.nrho = 0.75;
    p.alphaF = 0;
    p.betaf = 0*pi/180;
    p.zf = 0;
    p.xf = 0;
    p.yf = 0;
end