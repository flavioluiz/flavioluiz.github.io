%-------------------------------------------------

function sys = dinamicaaero(~,x,U, params)
global g

%controles
d=U(1); dp=U(2); da=U(3); dr=U(4);

%estados
Vt=x(1); a=x(2); b=x(3); p=x(4); q=x(5);
r=x(6); fi=x(7); teta=x(8); psi=x(9); xo=x(10);
yo=x(11); H=x(12);

u = Vt*cos(a) * cos(b);
v = Vt*sin(b);
w = Vt*sin(a)*cos(b);

ro=densidade(H); qS=.5*ro*params.S*Vt^2; 

%Relacoes cinematicas de posicao
Hponto=u*sin(teta)-v*sin(fi)*cos(teta)-w*cos(fi)*cos(teta);
xop=u*cos(teta)*cos(psi)+v*(sin(fi)*sin(teta)*cos(psi)-cos(fi)*sin(psi))+ ...
      w*(cos(fi)*sin(teta)*cos(psi)+sin(fi)*sin(psi));
yop=u*cos(teta)*sin(psi)+v*(sin(fi)*sin(teta)*sin(psi)+cos(fi)*cos(psi))+ ...
      w*(cos(fi)*sin(teta)*sin(psi)-sin(fi)*cos(psi));

%Calculo dos coeficientes e forcas aerodinamicas
CL=coefsust(a,dp,q,params);
CD=params.CD0+params.k1*CL+params.k2*CL^2;
Cy=params.Cyb*b+params.Cyda*da+params.Cydr*dr+(params.Cyp*p+params.Cyr*r)*params.b/params.Vref;

F = d* params.Tmax0* (ro/params.rho0)^params.nrho * (Vt/params.V0)^params.nv;
Th = 0;
hf = 0;

Fx=qS*(CL*sin(a)-CD*cos(a)*cos(b))+F*cos(params.alphaF)*cos(params.betaf);
Fy=qS*Cy+F*sin(params.betaf);
Fz=qS*(-CL*cos(a)-CD*sin(a)*cos(b))+F*sin(params.alphaF)*cos(params.betaf);

up=(Fx-g*params.m*sin(teta)-params.m*(-r*v+q*w))/params.m;
vp=(Fy+g*params.m*cos(teta)*sin(fi)-params.m*(r*u-p*w))/params.m;
wp=(Fz+g*params.m*cos(fi)*cos(teta)+params.m*(q*u-p*v))/params.m;

ap=(u*wp-w*up)/(u*u+w*w);

Cm=coefmomarf(a,dp,q,ap,params);
Cl=params.Clb*b+params.Clda*da+params.Cldr*dr+(params.Clp*p+params.Clr*r)*params.b/params.Vref;
Cn=params.Cnb*b+params.Cnda*da+params.Cndr*dr+(params.Cnp*p+params.Cnr*r)*params.b/params.Vref;
Naed=qS*params.b*Cn;
Maed=qS*params.c*Cm;
Laed=qS*params.b*Cl; 

%Momento aerodin�mico + momento propulsivo:
Lt=Laed+Th*cos(params.alphaF)*cos(params.betaf)+F*params.yf*cos(params.betaf)*sin(params.alphaF)-F*params.zf*sin(params.betaf); 
Mt=Maed+F*params.zf*cos(params.alphaF)*cos(params.betaf)-F*params.xf*cos(params.betaf)*sin(params.alphaF)+Th*sin(params.betaf); 
Nt=Naed-F*params.yf*cos(params.alphaF)*cos(params.betaf)+Th*cos(params.betaf)*sin(params.alphaF)+F*params.xf*sin(params.betaf);

%equacoes da dinamica de rotacao (pp, qp, rp):Ix
qp=(Mt-params.Ixz*p^2-params.Ixx*p*r+params.Izz*p*r+params.Ixz*r^2+hf*cos(params.betaf)*(-(r*cos(params.alphaF))+p*sin(params.alphaF)))/params.Iyy;
pp=-((params.Izz*Lt+params.Ixz*Nt+q*((-params.Ixz^2+params.Iyy*params.Izz-params.Izz^2)*r+hf*cos(params.betaf)*(params.Ixz*cos(params.alphaF)-params.Izz*sin(params.alphaF)))+hf*params.Izz*r*sin(params.betaf)+ ... 
     params.Ixz*p*((params.Ixx-params.Iyy+params.Izz)*q-hf*sin(params.betaf)))/(params.Ixz^2-params.Ixx*params.Izz));
rp=(-(params.Ixx*Nt)+q*(params.Ixz*(params.Ixx-params.Iyy+params.Izz)*r+hf*cos(params.betaf)*(-(params.Ixx*cos(params.alphaF))+params.Ixz*sin(params.alphaF)))+ ... 
    p*((-params.Ixx^2-params.Ixz^2+params.Ixx*params.Iyy)*q+hf*params.Ixx*sin(params.betaf))-params.Ixz*(Lt+hf*r*sin(params.betaf)))/(params.Ixz^2-params.Ixx*params.Izz);

%equacoes cinematicas de rotacao (taxas de variacao dos angulos de Euler em
%funcao das velocidades angulares p,q,r):
tetap=q*cos(fi)-r*sin(fi);
fip=p+tan(teta)*(q*sin(fi)+r*cos(fi));
psip=(q*sin(fi)+r*cos(fi))/cos(teta);

% Vp, alphap, betap:
Vtp=(u*up+v*vp+w*wp)/Vt;
ap=(u*wp-w*up)/(u*u+w*w);
bp=(Vt*vp-v*Vtp)/(Vt*sqrt(u*u+w*w));

sys = [Vtp
    ap   
    bp
    pp
    qp
    rp
    fip
    tetap
    psip    
    xop
    yop
    Hponto];
