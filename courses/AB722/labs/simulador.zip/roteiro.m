clear all; clc;
global g g0;
g0=9.80665; g=g0;

fr=180/pi; drmax = 20*pi/180; damax = 20*pi/180; dpmax = 20*pi/180;

params = carregaa310;
% params = carregaa310;
% params = carregavant;

%.............................Equilibrio...................................
He=200;
Ve=250;
be=0*pi/180;% beta
omega=0*pi/(180);% velocidade angular (�/s)

psie = 120*pi/180; %proa inicial
xoe = +100*cos((180-120)*pi/180); %posicao x0
yoe = -100*sin((180-120)*pi/180); %posicao y0

%%Equilibrio setando 'beta'
y0=[0.5 0 0 0 0 0 0]; %y0 = [d0 a0 fi0 teta0 dp0 da0 dr0]
y=fsolve(@equilibriobeta,y0,[],[Ve, He, be, omega], params);
dme=y(1); ae=y(2); fie=y(3); tetae=y(4);
dpe=y(5); dae=y(6); dre=y(7);

%%Equilibrio setando 'fi'
%y0=[0.5 0 0 0 0 0 0]; %y0 = [d0 a0 b0 teta0 dp0 da0 dr0]
%fie = 0*pi/180;
%y=fsolve(@equilibriofi,y0,[],[Ve, He, fie, omega], params);
%dme=y(1); ae=y(2); be=y(3); tetae=y(4);
%dpe=y(5); dae=y(6); dre=y(7);

pe=-omega*sin(tetae);
qe=omega*cos(tetae)*sin(fie);
re=omega*cos(tetae)*cos(fie);

fprintf('\n')
disp('Condicoes de Equilibrio');
disp(['Altitude(m): ',num2str(He)]);
disp(['Velocidade(m/s): ',num2str(Ve)]);
disp(['Omega(�/s): ',num2str(omega*fr)]);
disp(['Angulo de Derrapagem (�): ',num2str(be*fr)]);

fprintf('\n')
disp('Resultados do Equilibrio');
disp(['Manete(%): ',num2str(100*dme)]);
disp(['Angulo de ataque(�): ',num2str(ae*fr)]);
disp(['Angulo de derrapagem(�): ',num2str(be*fr)]);
disp(['Angulo de atitude(�): ',num2str(tetae*fr)]);
disp(['Angulo de inclina��o lateral(�): ',num2str(fie*fr)]);
disp(['Deflexao do profundor(�): ',num2str(dpe*fr)]);
disp(['Deflexao do aileron(�): ',num2str(dae*fr)]);
disp(['Deflexao do leme(�): ',num2str(dre*fr)]);

ue = Ve*cos(ae)*cos(be);
ve = Ve*sin(be);
we = Ve*sin(ae)*cos(be);

xeq = [ue ve we pe qe re fie tetae psie xoe yoe He];
ueq = [dme,dpe,dae,dre];
xeqaero = [Ve ae be pe qe re fie tetae psie xoe yoe He];

DTA = 1e-5; % 'delta' da linearizacao

[A B] = linearizacorpo(xeq, ueq, DTA, params);
[Aaero Baero] = linearizaaero(xeqaero, ueq, DTA, params);


%% Abrindo o FlightGear
% fprintf('\n')
% disp('aperte enter para inicializar')
% disp('o visualizador FlightGear e o simulador em simulink')
% disp('aguarde abrir completamente')
% pause
dos('runfg.bat &');