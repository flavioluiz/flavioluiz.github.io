%......................Modelo Temperatura.................................
function T = temperatura(H)
T0 = 288.15;
L = -6.5e-3;
H0 = 0;
if H <= 11000
    T = T0 + L*(H-H0);
else
    T = temperatura(11000);
end