%.....................Modelo densidade...................................
function rho = densidade(H)
g0 = 9.8; 
rho0 = 1.225;
R = 287.053;L=-6.5e-3;
T0 = 288.15;

if H<= 11000
    rho = rho0*(temperatura(H)/T0)^-(1+g0/(R*L));
else
    rho = densidade(11000)*exp(-g0*(H-11000)/(R*temperatura(11000)));
end