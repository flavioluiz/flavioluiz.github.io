function [Aaero Baero] = linearizaaero(xeqaero, ueq, DTA, params)
        Aaero = zeros(12,12);
        for i = 1:12
           delta = zeros(1,12);
           delta(i) = 1;
           coluna = (dinamicaaero(0, xeqaero+DTA*delta, ueq,params) - dinamicaaero(0, xeqaero-DTA*delta, ueq,params))/(2*DTA);
           Aaero(:,i) = coluna;
        end
        Baero = zeros(12,4);
        for i = 1:4
           delta = zeros(1,4);
           delta(i) = 1;
           coluna = (dinamicaaero(0, xeqaero, ueq+DTA*delta,params) - dinamicaaero(0, xeqaero, ueq-DTA*delta,params))/(2*DTA);
           Baero(:,i) = coluna;
        end
end