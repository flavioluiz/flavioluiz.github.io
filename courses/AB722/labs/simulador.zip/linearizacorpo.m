function [A B] = linearizacorpo (xeq, ueq, DTA, params)
        A = zeros(12,12);
        for i = 1:12
           delta = zeros(1,12);
           delta(i) = 1;
           coluna = (dinamicacorpo(0, xeq+DTA*delta, ueq,params) - dinamicacorpo(0, xeq-DTA*delta, ueq,params))/(2*DTA);
           A(:,i) = coluna;
        end
        B = zeros(12,4);
        for i = 1:4
           delta = zeros(1,4);
           delta(i) = 1;
           coluna = (dinamicacorpo(0, xeq, ueq+DTA*delta,params) - dinamicacorpo(0, xeq, ueq-DTA*delta,params))/(2*DTA);
           B(:,i) = coluna;
        end
end