function [sys,x0,str,ts] = sfunctionvant(t,x,u,flag,X0,params)
switch flag,

  case 0
    [sys,x0,str,ts]=inicializa(X0); 

  case 1
    sys = dinamicacorpo(t,x,u,params); 

  case 3
    sys = saidas(t,x,u);
  
  case { 2, 4, 9 }
    sys = [];
  otherwise
    error(['Unhandled flag = ',num2str(flag)]); 
end

%--------------------------------------------------

function [sys,x0,str,ts] = inicializa(X0)

sizes = simsizes;
sizes.NumContStates  = 12;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 15;
sizes.NumInputs      = 4;
sizes.DirFeedthrough = 0;
sizes.NumSampleTimes = 1;
sys = simsizes(sizes);

x0 = X0;

str = [];

ts = [0 0];

%--------------------------------------------------

function sys = saidas(~,x,~)
u = x(1);
v = x(2);
w = x(3);
Vt = sqrt(u^2 + v^2 + w^2);
a = atan(w/u);
b = asin(v/Vt);
sys = [x;Vt; a;b];