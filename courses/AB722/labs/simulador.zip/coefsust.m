function CL = coefsust(a,dp,q, params)
CL = params.CL0+params.CLalpha*a+params.CLdp*dp+params.CLq*q*params.c/params.Vref;

gr = 3;
CLmax = 1;
c1 = CLmax - (1/(gr))^(1/(gr-1)) + (1/(gr))^(gr/(gr-1));
if CL > c1
    CL = CL - (CL - c1)^4;
    if CL < 0.2
        CL = 0.2*exp(CL-0.2) ;
    end
end

if CL < -c1
    CL = CL + (CL + c1)^4;
    if CL > -0.2
        CL = -0.2*exp(-CL-0.2) ;
    end
end