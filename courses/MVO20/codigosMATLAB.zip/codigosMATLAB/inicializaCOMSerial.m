function portaCOM = inicializaCOMSerial(nomePortaCOM)
%inicializa a comunica��o com a porta serial entre Arduio e Matlab. Ele
%garante que esta ocorrendo a comunica��o entre arduino e Matlab e o Matlab
%pode come�ar a receber/transmitir dados. Deve ser usada antes de qualquer
%programa que a interface entre os dois sistemas exista.
%Refer�ncia: http://www.matlabarduino.org/
%ENTRADA: endere�o da porta COM
%SAIDA: 1 quando a comunica��o esta completa e 0 caso contr�rio

portaCOM = serial(nomePortaCOM);
set(portaCOM,'DataBits', 8);
set(portaCOM,'StopBits', 1);
set(portaCOM,'BaudRate', 9600);
set(portaCOM,'Parity', 'none');
fopen(portaCOM);
leituraMatlab = fread(portaCOM,1,'uchar');
while (leituraMatlab ~= 'a')
    leituraMatlab = fread(portaCOM,1,'uchar');
end
if (leituraMatlab == 'a')
    disp('lendo porta serial');
end
fprintf(portaCOM,'%c','m');
disp('comunica��o serial estabelecida.');
fscanf(portaCOM,'%c');