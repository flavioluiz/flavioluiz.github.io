warning off
clear all
clc
nomePortaCOM = 'COM3';
portaCOM = inicializaCOMSerial(nomePortaCOM);
[dadosGravados,dadosPlot] = obterPlot(portaCOM);
save('PARAM.mat','dadosGravados','dadosPlot');
fprintf(portaCOM, 'C');
fechaCOMSerial(portaCOM);