function [dadosGravados,dadosPlot] = obterPlot(portaCOM)
buffer = 100;
eixoX = 1:buffer;
dadosGravados=[];
dadosPlotados = zeros(buffer,3);
tempoExecucao = 0;
H = uicontrol('style','pushbutton','String', 'Parar','position',[0 0 50 25],...
    'Callback',@stopf, 'UserData', 1);
Leitor = uicontrol('style','pushbutton','String', 'Iniciar aquis.','position',[50 0 100 25],...
    'Callback',@stopf, 'UserData', 1);
Sttoper = uicontrol('style','pushbutton','String', 'Parar aquis.','position',[200 0 100 25],...
    'Callback',@stopf, 'UserData', 1);
Valor = uicontrol('style','edit','position',[300 0 100 25],...
    'Callback',@stopf, 'UserData', 1,'String',50);
set(Valor, 'String',num2str(5));
dadosPlot=[];
while  get(H, 'UserData') == 1
    [dado, PWM] = leDadosCurvaMomento(portaCOM, Valor);
    dado = calibraPotenciometro(dado);
    windowSize = 60;
    b = (1/windowSize)*ones(1,windowSize);
    a=1;
    valoresFiltrados = filter(b,a, [dadosPlotados(:,2)]);
    dadosI_1(1) = valoresFiltrados(end-1);
    dadosI_1(2) = dadosPlotados(end-1,1);
    dadosI_1(3) = valoresFiltrados(end);
    dadosI_1(4) = dadosPlotados(end,1);
    dado = geraDerivada(dado(end,:),dadosI_1);
    cla;
    while get(Leitor, 'UserData') == 0
        dadosGravados = [dadosGravados; dado];
        dadosPlotados = [dadosPlotados(2:end,:);dado];
        subplot(2,1,1);plot(eixoX, dadosPlotados(:,2),'m');
        grid on;
        xlim([0 100]);%ylim([-90 90]);
        xlabel('amostras'); ylabel('�ngulo(�)');
        subplot(2,2,3);plot(eixoX, dadosPlotados(:,3),'m');
        grid on;
        xlim([0 100]);%ylim([-90 90]);
        xlabel('amostras'); ylabel('d\theta/dt(�/s)');
        drawnow;
        if get(Sttoper, 'UserData') == 0
            valorAngulo = mean(dadosGravados(:,2));
            PWM = get(Valor, 'String');PWM = str2num(PWM);
            valorEntrada = PWM;
            dadosPlot = [dadosPlot; valorEntrada valorAngulo];[l,c]=size(dadosPlot);
            subplot(2,2,4);plot(dadosPlot(:,1),dadosPlot(:,2),'mo','MarkerFaceColor','m');
            grid on;%xlim([0 100]);ylim([-90 90]);
            xlabel('PWM'); ylabel('\theta(�)');
            set(Leitor, 'UserData', 1);
            save('PARAM.mat','dadosPlot');
            dadosGravados=[];
        end
        set(Sttoper, 'UserData', 1);
        valoresFiltrados = filter(b,a, [dadosPlotados(:,2)]);
%     valoresFiltrados = smooth(dadosPlotados(:,2),30);
        dadosI_1(1) = valoresFiltrados(end-1);
        dadosI_1(2) = dadosPlotados(end-1,1);
        dadosI_1(3) = valoresFiltrados(end);
        dadosI_1(4) = dadosPlotados(end,1);
        [dado PWM] = leDadosCurvaMomento(portaCOM,Valor);
        dado = calibraPotenciometro(dado);
        dado = geraDerivada(dado(end,:),dadosI_1);
%         dado = geraDerivada(dado,dadosPlotados(end-tamanhoFiltro+1:end,:));
    end
    dadosPlotados = [dadosPlotados(2:end,:);dado];
    subplot(2,1,1);plot(eixoX, dadosPlotados(:,2),'m');
    grid on;
    xlim([0 100]);%ylim([-90 90]);
    xlabel('amostras'); ylabel('�ngulo(�)')
    subplot(2,2,3);plot(eixoX, dadosPlotados(:,3),'m');
    grid on;
    xlim([0 100]);%ylim([-90 90]);
    xlabel('amostras'); ylabel('d\theta/dt(�/s)');
    drawnow;
    tempoExecucao = dado(1);
end
end
function c = stopf(H, EventData)
set(H, 'UserData', 0);
c = get(H, 'UserData');
end
