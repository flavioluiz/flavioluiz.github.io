function dadoGerado = geraDerivada(dadoI, dadoI_1)
% thetaFinal = mean([dadoI(2); dadoI_1(2:end,2)]);
thetaFinal = dadoI_1(3);
% thetaInicio = mean(dadoI_1(:,2));
thetaInicio = dadoI_1(1);
if (dadoI_1(4)==dadoI_1(2))
    dadoI_1(2)=.1;
end
thetaPonto = (thetaFinal - thetaInicio)/(dadoI_1(4) - dadoI_1(2));
dadoGerado = [dadoI(1) dadoI(2) thetaPonto];
end
