function dadoGerado = calibraPotenciometro(dado)
%posicao = .37344*dado(2)-191.2;
%dadoGerado = [dado(1) posicao ];
dadoGerado = [dado(1) dado(2) ];
end
