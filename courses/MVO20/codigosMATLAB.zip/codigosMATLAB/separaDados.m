function [dados01 dados02] = separaDados
clc;clear all;
load PARAM.mat
dadosPlot(:,2) = dadosPlot(:,2)-58.59;
dadosPlot = sortrows(dadosPlot,2);
plot(dadosPlot(:,1),dadosPlot(:,2),'o');xlabel('time');ylabel('teta');
grid on;
[x y] = ginput(4);
dados01 = []; i =1;
theta = dadosPlot(1,2);
while theta <= y(2)
    dados01 = [dados01;dadosPlot(i,:)];
    i=i+1;
    theta = dadosPlot(i,2);
end
tempo=dadosPlot(i,1);
while tempo < x(3)
    i=i+1;
    tempo=dadosPlot(i,1);
end
dados02 = []; referencia=i;
tempo = dadosPlot(i,1);
while tempo >= x(3) & i<max(size(dadosPlot))
    i=i+1;
    theta = dadosPlot(i,2);
    tempo = dadosPlot(i,1);
    dados02 = [dados02;dadosPlot(i,:)];
end
p01 = polyfit(dados01(:,1),dados01(:,2),1)
y01 = polyval(p01,dados01(:,1));
xzero01 = -p01(2)/p01(1)
p02 = polyfit(dados02(:,1),dados02(:,2),1)
y02 = polyval(p02,dados02(:,1));
xzero02 = -p02(2)/p02(1)
hold on; plot(dados01(:,1),y01);
hold on; plot(dados02(:,1),y02);
end