function [parametros PWM] = leDadosCurvaMomento(portaCOM, Valor)
    fprintf(portaCOM, 'R');
%     PWM = fscanf(portaCOM,'%f');set(Valor, 'String', num2str(PWM));
    PWM = get(Valor, 'String');
    PWM = str2num(PWM);
    palavra = ['W' num2str(PWM)];
    fprintf(portaCOM,palavra);
    tempo = fscanf(portaCOM,'%u');
    valorSensor = fscanf(portaCOM,'%u');
%     valorSensorEntrada = fscanf(portaCOM,'%u');
    tempoSegundos = tempo*0.001;
    PWM = fscanf(portaCOM,'%f');
    parametros = [tempoSegundos valorSensor ];
end