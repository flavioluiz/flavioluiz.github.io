%% MVO-20 - Aula 25: desempenho, projeto e revisao
% 17/11/2026, 10h-12h. MATLAB R2023b + Control System Toolbox.
% Os exemplos pressupõem realimentacao negativa unitaria e ausencia de saturacao.
clear; close all; clc;
s=tf('s');

%% 1. Selecao de ganho, retomada do capitulo 10 de AS-765
P=1/(s*(s+2)*(s+6)); K=10.7;
figure('Name','Escolha de ganho'); rlocus(P); grid on; sgrid(0.6,[]);
% [K,p]=rlocfind(P); % opcional: escolher ganho com o mouse
T=feedback(K*P,1); p=pole(T);
[wn,zeta,p]=damp(T);
disp(table(p,wn,zeta));
assert(max(abs(polyval([1 8 12 K],p)))<1e-10);
assert(isstable(T));
t=(0:0.005:10).'; y=step(T,t);
S=stepinfo(y,t,dcgain(T),'SettlingTimeThreshold',0.02);
assert(S.Overshoot<10 && S.SettlingTime<5.5);
fprintf('Exemplo 1: Mp=%.4f%%, ts=%.4f s\n',S.Overshoot,S.SettlingTime);
par=p(imag(p)>0); wn2=abs(par); z2=-real(par)/wn2;
T2=wn2^2/(s^2+2*z2*wn2*s+wn2^2);
figure('Name','Par dominante'); step(T,T2,t); grid on;
legend('Modelo completo','Par dominante','Location','best');
% Erro de rampa. minreal apenas elimina o fator s usado no limite s*L.
Kv=dcgain(minreal(s*K*P,1e-8));
assert(abs(Kv-K/12)<1e-12);
fprintf('Kv=%.6f; erro de rampa=%.6f\n',Kv,1/Kv);

%% 2. Compensacao sem cancelamento
P=1/(s*(s+2)); sd=-2+2i;
phiP=angle(evalfr(P,sd))*180/pi; phiC=180-phiP;
z=3; angZero=angle(sd+z)*180/pi; angPolo=angZero-phiC;
polo=2+2/tand(angPolo);
C0=(s+z)/(s+polo); Kc=1/abs(evalfr(C0*P,sd)); C=Kc*C0;
assert(abs(polo-8)<1e-12 && abs(Kc-16)<1e-12);
assert(abs(1+evalfr(C*P,sd))<1e-12);
Tc=feedback(C*P,1); Tp=feedback(2*P,1);
assert(max(abs(polyval([1 10 32 48],pole(Tc))))<1e-10);
assert(numel(pole(Tc))==3);
figure('Name','LGR compensado'); rlocus(C0*P); grid on;
t=(0:0.002:8).'; yc=step(Tc,t); yp=step(Tp,t);
Sc=stepinfo(yc,t,1,'SettlingTimeThreshold',0.02);
Sp=stepinfo(yp,t,1,'SettlingTimeThreshold',0.02);
assert(Sc.Overshoot<10 && Sc.SettlingTime<2.5);
figure('Name','Comparacao de projetos'); plot(t,yp,t,yc,'LineWidth',1.5);
grid on; xlabel('t [s]'); ylabel('y(t)');
legend('P: K=2','Avanco de fase','Location','best');
fprintf('P: Mp=%.4f%%, ts=%.4f s\n',Sp.Overshoot,Sp.SettlingTime);
fprintf('Avanco: Kc=%.4f, z=%.4f, p=%.4f, Mp=%.4f%%, ts=%.4f s\n', ...
 Kc,z,polo,Sc.Overshoot,Sc.SettlingTime);
% Comparar com o modelo canonico que tem o mesmo par.
Tideal=8/(s^2+4*s+8);
figure('Name','Efeito dos polos e zeros adicionais'); step(Tc,Tideal,t); grid on;
legend('Completo','Canonico do par','Location','best');
Uc=feedback(C,P); Up=feedback(tf(2),P);
uc=step(Uc,t); up=step(Up,t);
assert(abs(uc(1)-16)<1e-10 && abs(up(1)-2)<1e-10);
figure('Name','Comando solicitado'); plot(t,up,t,uc,'LineWidth',1.5);
grid on; xlabel('t [s]'); ylabel('u(t)'); xlim([0 3]);
legend('P: K=2','Avanco de fase','Location','best');

%% 3. Revisao de Bode, margens e Routh
L=8/(s*(s+2)*(s+4));
[gm,pm,w180,wgc]=margin(L);
assert(abs(gm-6)<1e-10);
assert(abs(w180-sqrt(8))<1e-10);
assert(abs(abs(evalfr(L,1i*w180))-1/6)<1e-12);
assert(isstable(feedback(5.9*L,1)));
assert(~isstable(feedback(6.1*L,1)));
figure('Name','Revisao de margens'); margin(L); grid on;
fprintf('MG=%.4f (%.4f dB), MF=%.4f graus, w180=%.4f, wgc=%.4f\n', ...
 gm,20*log10(gm),pm,w180,wgc);

%% 4. Revisao de PI, filtro e back-calculation
Ppi=1/(s+1); Cpi=3+4/s; Tpi=feedback(Cpi*Ppi,1);
assert(norm(sort(pole(Tpi))-[-2;-2])<1e-6);
assert(abs(zero(Tpi)+4/3)<1e-12);
Ki=2; e=1; u=1; v=3; Tt=0.5; dxI=Ki*e+(u-v)/Tt;
assert(dxI==-2);
fprintf('Revisao PI: Kp=3, Ki=4, zero=-4/3; dxI=%g\n',dxI);
fprintf('Todas as verificacoes passaram.\n');
