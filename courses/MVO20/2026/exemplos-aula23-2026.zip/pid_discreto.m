function [u,estado,sinais] = pid_discreto(r,ym,estado,p)
%PID_DISCRETO PID com D na medicao, saturacao e back-calculation.
% p: Kp, Ki, Kd, Tf>0, Tt>0, h>0, umin, umax.
% Na entrada: estado.q=q(k-1); estado.xI=xI(k), em unidades de comando.
% Na saida: estado.q=q(k); estado.xI=xI(k+1).
% Filtro: Euler implicito. Integral/anti-windup: Euler explicito.
% Atuador suposto: saturacao estatica. Manter u ate a proxima amostra.
% Inicializacao estacionaria: q=ym0; xI=u0-Kp*(r0-ym0).
% Troca manual/auto: manter q e ajustar xI=u_manual-Kp*e-uD atual.
assert(p.Tf>0 && p.Tt>0 && p.h>0 && p.umin<p.umax);
e=r-ym;
alpha=p.Tf/(p.Tf+p.h);
q=alpha*estado.q+(1-alpha)*ym;
uD=-p.Kd/p.Tf*(ym-q);
v=p.Kp*e+estado.xI+uD;
u=min(p.umax,max(p.umin,v));
sinais=struct('e',e,'uD',uD,'v',v,'xI',estado.xI);
estado.q=q;
estado.xI=estado.xI+p.h*(p.Ki*e+(u-v)/p.Tt);
end
