% Dados vetoriais dos slides da aula 24. MATLAB + Control System Toolbox.
% Execute nesta pasta. Nenhuma figura raster e necessaria para os graficos.
clear; clc;
base = fileparts(mfilename('fullpath'));
pasta = fullfile(base, 'Figuras');
s = tf('s');
sb = -2 + 2/sqrt(3); Kb = -sb*(sb+2)*(sb+4);
se = -3 + sqrt(3); Ke = -se*(se+3)*(se+6);
modelos = {1/(s*(s+2)), 1/(s*(s+2)*(s+4)), ...
    (s+2)/(s*(s+1)*(s+4)), 1/(s*(s+3)*(s+6))};
nomes = {'segunda','terceira','zero','exercicio'};
ganhos = {unique([linspace(0,1,101),linspace(1,12,250)]), ...
    unique([linspace(0,Kb,150),linspace(Kb,200,700),48]), ...
    unique([linspace(0,2,200),linspace(2,100,500)]), ...
    unique([linspace(0,Ke,150),linspace(Ke,500,700),162])};
for a = 1:numel(modelos)
    G = modelos{a}; k = ganhos{a}; r = rlocus(G,k);
    n = size(r,1); ordens = perms(1:n);
    % Associacao por continuidade. Em polos multiplos, os ramos coincidem.
    r(:,1) = sort(real(r(:,1)));
    for t = 2:numel(k)
        candidatos = reshape(r(ordens,t),size(ordens));
        custos = sum(abs(candidatos-r(:,t-1).').^2,2);
        [~,q] = min(custos); r(:,t) = candidatos(q,:).';
    end
    [num,den] = tfdata(G,'v'); num = [zeros(1,numel(den)-numel(num)),num];
    for t = 1:numel(k)
        % Residuo relativo do polinomio caracteristico.
        c = den+k(t)*num;
        residuo = abs(polyval(c,r(:,t)))./polyval(abs(c),abs(r(:,t)));
        residuo(~isfinite(residuo)) = 0; % raiz na origem para K=0
        assert(max(residuo)<1e-10);
    end
    f = fopen(fullfile(pasta,[nomes{a},'.dat']),'w');
    fprintf(f,'K'); for j=1:n, fprintf(f,' x%d y%d',j,j); end; fprintf(f,'\n');
    for t=1:numel(k)
        fprintf(f,'%.12g',k(t));
        for j=1:n, fprintf(f,' %.12g %.12g',real(r(j,t)),imag(r(j,t))); end
        fprintf(f,'\n');
    end
    fclose(f);
end
assert(abs(Kb-16/(3*sqrt(3)))<1e-12);
assert(abs(Ke-6*sqrt(3))<1e-12);
assert(abs(evalfr(modelos{1},-1+1i)+0.5)<1e-12);
assert(abs(evalfr(modelos{1},-2+1i)-(-0.2+0.4i))<1e-12);
for k=[1,3,8,48,80]
    fprintf('K=%g, polos do exemplo principal:\n',k);
    disp(roots([1,6,8,k]).');
end
assert(all(real(roots([1 6 8 47]))<0));
assert(sum(real(roots([1 6 8 49]))>0)==2);
assert(abs(polyval([1 6 8 48],1i*sqrt(8)))<1e-10);
assert(abs(polyval([1 9 18 162],1i*sqrt(18)))<1e-10);
fprintf('Saida principal: s=%.9f, K=%.9f\n',sb,Kb);
fprintf('Exercicio: s=%.9f, K=%.9f\n',se,Ke);
fprintf('Dados gerados e residuos conferidos.\n');
