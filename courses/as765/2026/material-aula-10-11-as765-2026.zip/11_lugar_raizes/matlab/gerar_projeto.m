function gerar_projeto
% Aula 25: dados dos graficos, metricas e verificacoes numericas.
clc;
base=fileparts(fileparts(mfilename('fullpath'))); out=fullfile(base,'Figuras');
s=tf('s'); G=1/(s*(s+2)*(s+6)); K=10.7; T=feedback(K*G,1);
p=pole(T); pc=p(imag(p)>0); wn=abs(pc); zeta=-real(pc)/wn;
T2=wn^2/(s^2+2*zeta*wn*s+wn^2);
t=(0:0.005:10).'; y=step(T,t); y2=step(T2,t);
salvar(fullfile(out,'ganho.dat'),{'t','y','y2'},[t y y2]);
S=stepinfo(y,t,1,'SettlingTimeThreshold',0.02);
S2=stepinfo(y2,t,1,'SettlingTimeThreshold',0.02);
fprintf('Ganho: polos\n'); disp(p.');
fprintf('zeta=%.9f wn=%.9f, Mp=%.6f, ts=%.6f, canonico Mp=%.6f ts=%.6f\n',zeta,wn,S.Overshoot,S.SettlingTime,S2.Overshoot,S2.SettlingTime);
assert(S.Overshoot<10 && S.SettlingTime<5.5);
assert(abs(dcgain(T)-1)<1e-12);
assert(abs(1+K*evalfr(G,pc))<1e-10);
assert(max(abs(polyval([1 8 12 K],p)))<1e-10);
P=1/(s*(s+2)); C0=(s+3)/(s+8); Kc=16; C=Kc*C0;
Tc=feedback(C*P,1); Tp=feedback(2*P,1); Tideal=8/(s^2+4*s+8);
Uc=feedback(C,P); Up=feedback(tf(2),P);
t=(0:0.002:8).'; yc=step(Tc,t); yp=step(Tp,t); yi=step(Tideal,t);
uc=step(Uc,t); up=step(Up,t);
salvar(fullfile(out,'lead.dat'),{'t','yp','yc','yi','up','uc'},[t yp yc yi up uc]);
Sc=stepinfo(yc,t,1,'SettlingTimeThreshold',0.02);
Sp=stepinfo(yp,t,1,'SettlingTimeThreshold',0.02);
Si=stepinfo(yi,t,1,'SettlingTimeThreshold',0.02);
sd=-2+2i;
assert(abs(evalfr(C*P,sd)+1)<1e-12);
assert(max(abs(polyval([1 10 32 48],pole(Tc))))<1e-10);
assert(Sc.Overshoot<10 && Sc.SettlingTime<2.5);
assert(abs(uc(1)-16)<1e-10 && abs(up(1)-2)<1e-10);
fprintf('Lead: planta fase=%.9f, C0 fase=%.9f, ganho=%.9f\n',angle(evalfr(P,sd))*180/pi,angle(evalfr(C0,sd))*180/pi,1/abs(evalfr(C0*P,sd)));
fprintf('Lead: polos\n');disp(pole(Tc).');
fprintf('P: Mp=%.6f ts=%.6f; lead: Mp=%.6f ts=%.6f; canonico: Mp=%.6f ts=%.6f\n',Sp.Overshoot,Sp.SettlingTime,Sc.Overshoot,Sc.SettlingTime,Si.Overshoot,Si.SettlingTime);
gs={G,P,C0*P,(s+3)/(s*(s+2)),1/(s*(s+2)*(s+8))}; nomes={'lgr_ganho','lgr_p','lgr_lead','efeito_zero','efeito_polo'};
ks={unique([linspace(0,20,500) linspace(20,150,300) 10.7]),unique([linspace(0,1,100) linspace(1,20,300) 2]),unique([linspace(0,30,500) linspace(30,200,300) 16]), ...
 unique([linspace(0,10,600) linspace(10,200,300)]),unique([linspace(0,20,300) linspace(20,600,400) 160])};
for m=1:numel(gs)
 r=rlocus(gs{m},ks{m}); n=size(r,1); perm=perms(1:n); [~,ord]=sort(real(r(:,1))); r(:,1)=r(ord,1);
 for q=2:size(r,2)
  candidatos=reshape(r(perm,q),size(perm));
  [~,idx]=min(sum(abs(candidatos-r(:,q-1).').^2,2)); r(:,q)=candidatos(idx,:).';
 end
 data=ks{m}(:); names={'K'};
 for j=1:n
  data=[data real(r(j,:)).' imag(r(j,:)).']; %#ok<AGROW>
  names=[names {sprintf('x%d',j),sprintf('y%d',j)}]; %#ok<AGROW>
 end
 salvar(fullfile(out,[nomes{m} '.dat']),names,data);
end
% Faixa de ganhos do exemplo 1 na regiao zeta>=0,6 e sigma>=4/5,5.
sig=4/5.5; Kmin=sig*(2-sig)*(6-sig);
sb1=(-16+sqrt(112))/6; Kb1=-sb1*(sb1+2)*(sb1+6);
par=@(K) max(roots([1 8 12 K]).*(imag(roots([1 8 12 K]))>0));
zf=@(K) -real(par(K))/abs(par(K))-0.6; Kmax=fzero(zf,[6 30]);
fprintf('Faixa: Kmin=%.6f, Kb=%.6f (sb=%.6f), Kmax=%.6f, par=%s\n',Kmin,Kb1,sb1,Kmax,num2str(par(Kmax)));
assert(abs(Kmin-4.8805)<1e-3 && abs(Kb1-5.0490)<1e-3 && abs(Kmax-11.3463)<1e-3);
assert(-real(par(Kmax))>sig && Kmax>10.7);
% Efeitos de zero e de polo.
assert(abs(polyval([1 10 16 160],4i))<1e-10);
% Revisao 2: avanco para P=1/[s(s+1)].
P1=1/(s*(s+1)); C1=20*(s+2)/(s+8); T1=feedback(C1*P1,1);
assert(abs(evalfr(C1*P1,sd)+1)<1e-12);
assert(max(abs(polyval(conv([1 5],[1 4 8]),pole(T1))))<1e-10);
t1=(0:0.001:10).'; y1=step(T1,t1); yf=step(2/(s+2)*T1,t1);
S1=stepinfo(y1,t1,1,'SettlingTimeThreshold',0.02); Sf=stepinfo(yf,t1,1,'SettlingTimeThreshold',0.02);
fprintf('Revisao 2: angulo P=%.6f; Mp=%.6f ts=%.6f; com pre-filtro Mp=%.6f ts=%.6f\n', ...
 angle(evalfr(P1,sd))*180/pi,S1.Overshoot,S1.SettlingTime,Sf.Overshoot,Sf.SettlingTime);
assert(S1.Overshoot>10 && Sf.Overshoot<10 && Sf.SettlingTime<2.5);
L=8/(s*(s+2)*(s+4)); [gm,pm,w180,wgc]=margin(L);
fprintf('Revisao K8: GM=%.9f, dB=%.9f, MF=%.9f w180=%.9f wgc=%.9f\n',gm,20*log10(gm),pm,w180,wgc);
assert(abs(gm-6)<1e-10 && abs(w180-sqrt(8))<1e-10);
assert(isstable(feedback(L,1)));
fprintf('Todas as conferencias numericas passaram.\n');
end

function salvar(nome,colunas,data)
 f=fopen(nome,'w'); fprintf(f,'%s\n',strjoin(colunas,' '));
 fmt=[repmat('%.12g ',1,size(data,2)-1) '%.12g\n'];
 fprintf(f,fmt,data.'); fclose(f);
end
