function demo_fundamentos
%% Aula 24 - Lugar das raizes: fundamentos
% AS-765, 10/11/2026. MATLAB + Control System Toolbox.
% Realimentacao negativa unitaria. K e o ganho externo a L0.
close all; clc;
s = tf('s');

%% 1. Exemplo de segunda ordem e condicoes de angulo/modulo
G2 = 1/(s*(s+2));
figure('Name','Exemplo inicial'); rlocus(G2); grid on;
axis([-3 1 -3 3]);
for K = [0.5 1 2 5]
    p = rlocus(G2,K);
    p_exato = [-1+sqrt(complex(1-K)); -1-sqrt(complex(1-K))];
    assert(distancia_conjuntos(p,p_exato)<1e-7);
    fprintf('Segunda ordem, K=%g:\n',K); disp(p.');
end
sd = -1+1i;
valor = evalfr(G2,sd);
K = 1/abs(valor);
assert(abs(1+K*valor)<1e-12);
fprintf('Ponto -1+j: fase=%g graus, K=%g\n',angle(valor)*180/pi,K);
sr = -2+1i;
K_exigido = -1/evalfr(G2,sr);
assert(abs(imag(K_exigido))>1);
fprintf('Ponto -2+j: ganho exigido=%g%+gj (fora do LGR positivo).\n', ...
    real(K_exigido),imag(K_exigido));

%% 2. Exemplo principal: tres polos
L0 = 1/(s*(s+2)*(s+4));
sb = -2+2/sqrt(3); Kb = -sb*(sb+2)*(sb+4);
Kcr = 48; wcr = sqrt(8);
figure('Name','Exemplo principal'); rlocus(L0); grid on;
axis([-8 2 -5 5]);
for K = [1 3 Kb 8 47 Kcr 49 80]
    p_lgr = rlocus(L0,K);
    p_mf = pole(feedback(K*L0,1));
    p_pol = roots([1 6 8 K]);
    assert(distancia_conjuntos(p_lgr,p_mf)<1e-6);
    assert(distancia_conjuntos(p_lgr,p_pol)<1e-6);
end
assert(abs(polyval([1 6 8 Kb],sb))<1e-12);
assert(abs(polyval([3 12 8],sb))<1e-12);
assert(distancia_conjuntos(roots([1 6 8 Kcr]),[-6;1i*wcr;-1i*wcr])<1e-10);
assert(isstable(feedback(47*L0,1)));
assert(~isstable(feedback(49*L0,1)));
fprintf('Exemplo principal: sb=%.6f, Kb=%.6f, Kcr=%g, wcr=%.6f\n', ...
    sb,Kb,Kcr,wcr);

% Respostas adicionais para discutir na continuidade da aula.
t = 0:0.01:15;
figure('Name','Ganhos estaveis no exemplo principal');
step(feedback(3*L0,1),feedback(8*L0,1),feedback(30*L0,1),t);
grid on; legend('K=3','K=8','K=30','Location','best');

%% 3. Exemplo com zero, retomado do material de AS-765
Gz = (s+2)/(s*(s+1)*(s+4));
figure('Name','Exemplo com zero'); rlocus(Gz); grid on;
axis([-5 1 -5 5]);
% K(s)=-D/N. Candidatos: D'(s)N(s)-D(s)N'(s)=0.
D = [1 5 4 0]; N = [1 2];
q = conv(polyder(D),N)-conv(D,polyder(N));
candidatos = roots(q);
for a = 1:numel(candidatos)
    z = candidatos(a);
    if abs(imag(z))<1e-10
        z = real(z); Kz = -polyval(D,z)/polyval(N,z);
        if Kz>0 && ((z>-4 && z<-2) || (z>-1 && z<0))
            fprintf('Exemplo com zero: saida em %.9f, K=%.9f\n',z,Kz);
            assert(abs(polyval(D,z)+Kz*polyval(N,z))<1e-10);
        end
    end
end

%% 4. Exercicio: 1/[s(s+3)(s+6)]
Ge = 1/(s*(s+3)*(s+6));
se = -3+sqrt(3); Ke = 6*sqrt(3);
assert(abs(polyval([1 9 18 Ke],se))<1e-10);
assert(abs(polyval([3 18 18],se))<1e-10);
assert(distancia_conjuntos(roots([1 9 18 162]), ...
    [-9;1i*sqrt(18);-1i*sqrt(18)])<1e-10);
assert(isstable(feedback(161*Ge,1)));
assert(~isstable(feedback(163*Ge,1)));
figure('Name','Exercicio'); rlocus(Ge); grid on;
axis([-11 2 -6 6]);
fprintf('Exercicio: saida=%.6f, Kb=%.6f, 0<K<162.\n',se,Ke);
%% 5. Polos complexos de malha aberta: angulo de partida
Gc = 1/(s*(s^2+4*s+8)); pk = -2+2i;
phi = 180 - angle(pk)*180/pi - angle(pk-conj(pk))*180/pi;   % -45 graus
assert(abs(phi+45)<1e-12);
assert(distancia_conjuntos(roots([1 4 8 32]),[-4;1i*sqrt(8);-1i*sqrt(8)])<1e-10);
figure('Name','Polos complexos'); rlocus(Gc); grid on; axis([-5 2 -4.5 4.5]);
fprintf('Partida de -2+2j: %.1f graus; 0<K<32.\n',phi);

fprintf('Conferencias concluidas.\n');

end

function d = distancia_conjuntos(a,b)
% Compara conjuntos pequenos de polos sem depender da ordem de retorno.
    a = a(:); b = b(:);
    assert(numel(a)==numel(b));
    ordens = perms(1:numel(b));
    candidatos = reshape(b(ordens),size(ordens));
    d = min(max(abs(candidatos-a.'),[],2));
end
