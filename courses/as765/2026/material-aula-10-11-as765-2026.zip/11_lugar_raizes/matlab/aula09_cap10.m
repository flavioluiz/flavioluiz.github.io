function aula09_cap10(bloco)
% AS-765 2026 - 10/11 - Lugar das raizes e projeto.
% Use 'fundamentos', 'projeto', 'validar', 'dados' ou 'todos' (padrao).
% Requer Control System Toolbox. Execute a partir da pasta deste arquivo.
if nargin==0, bloco='todos'; end
switch lower(char(bloco))
 case 'fundamentos', demo_fundamentos;
 case 'projeto', demo_projeto;
 case 'validar', validar_dados;
 case 'dados', gerar_fundamentos; gerar_projeto; validar_dados;
 case 'todos', demo_fundamentos; demo_projeto; validar_dados;
 otherwise, error('Use fundamentos, projeto, validar, dados ou todos.');
end
fprintf('AS-765 cap.10: bloco %s concluido.\n',char(bloco));
end
