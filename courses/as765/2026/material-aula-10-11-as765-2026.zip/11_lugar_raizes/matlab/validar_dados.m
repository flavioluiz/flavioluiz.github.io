function validar_dados
% Confere as tabelas dos slides contra os modelos declarados.
pasta=fullfile(fileparts(fileparts(mfilename('fullpath'))),'Figuras');
s=tf('s');
G=1/(s*(s+2)*(s+6)); T=feedback(10.7*G,1);
p=pole(T); par=p(imag(p)>0); wn=abs(par); zeta=-real(par)/wn;
assert(zeta>=0.6 && -real(par)>=4/5.5);
T2=wn^2/(s^2+2*zeta*wn*s+wn^2);
conferir(pasta,'ganho.dat','y',T); conferir(pasta,'ganho.dat','y2',T2);
P=1/(s*(s+2)); C=16*(s+3)/(s+8);
Tc=feedback(C*P,1); Tp=feedback(2*P,1);
conferir(pasta,'lead.dat','yc',Tc); conferir(pasta,'lead.dat','yp',Tp);
conferir(pasta,'lead.dat','yi',8/(s^2+4*s+8));
conferir(pasta,'lead.dat','uc',feedback(C,P));
conferir(pasta,'lead.dat','up',feedback(tf(2),P));
% Cada linha do LGR e um conjunto de raizes de D+KN.
modelos={1/(s*(s+2)),1/(s*(s+2)*(s+4)),(s+2)/(s*(s+1)*(s+4)), ...
 1/(s*(s+3)*(s+6)),G,P,(s+3)/(s*(s+2)*(s+8)),1/(s*(s^2+4*s+8)), ...
 (s+3)/(s*(s+2)),1/(s*(s+2)*(s+8))};
nomes={'segunda','terceira','zero','exercicio','lgr_ganho','lgr_p','lgr_lead', ...
 'complexo','efeito_zero','efeito_polo'};
for a=1:numel(modelos)
 B=readtable(fullfile(pasta,[nomes{a} '.dat']),'FileType','text');
 [num,den]=tfdata(modelos{a},'v');
 num=[zeros(1,numel(den)-numel(num)),num]; n=numel(den)-1;
 for k=1:height(B)
  c=den+B.K(k)*num;
  for j=1:n
   z=B.(sprintf('x%d',j))(k)+1i*B.(sprintf('y%d',j))(k);
   escala=polyval(abs(c),abs(z));
   if escala>0, assert(abs(polyval(c,z))/escala<1e-8); end
  end
 end
end
fprintf('Tabelas: respostas e dez lugares das raizes conferidos.\n');
end
function conferir(pasta,arquivo,coluna,T)
 B=readtable(fullfile(pasta,arquivo),'FileType','text');
 y=step(T,B.t); assert(max(abs(y(:)-B.(coluna)))<1e-8);
end
