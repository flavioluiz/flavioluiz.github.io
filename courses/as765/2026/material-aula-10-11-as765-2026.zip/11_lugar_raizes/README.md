# AS-765 — Aula de 10/11/2026 — Capítulo 10

Apresentação com **57 slides**, para a Aula 9 de AS-765, na reposição de
terça-feira à tarde. Mantém o modelo Beamer de 2026: Darmstadt/beaver, 16:9,
capa do E-190 e logotipo do ITA. O roteiro projetado não contém horários.

## Uniformidade com MVO-20 de 2026

O núcleo da apresentação usa os mesmos exemplos, gráficos, equações, notação
e ordem das aulas 24 e 25 de MVO-20, na versão final de 06/11/2026.
Os dois encontros de MVO-20 foram consolidados em uma apresentação de AS-765.
Mudam a identificação da disciplina, o roteiro de abertura, as chamadas de
continuidade e o fechamento.

Foram retirados a revisão de Bode/PID para a prova, a preparação para a prova de
24/11 e o encerramento do conteúdo de MVO-20. Foram mantidos os exercícios
específicos de construção e decisão de projeto pelo LGR. AS-765 continua em
16/11 com projeto no domínio da frequência.

## Roteiro sugerido para quatro horas

| Slides | Conteúdo | Tempo de referência |
|---|---|---:|
| 1–16 | Equação característica, exemplo inicial, ângulo/módulo, ramos, eixo real, assíntotas e exemplo com zero | 35 min |
| 17–27 | Exemplo de três polos, saída do eixo real, fronteira por Routh e ângulo de partida | 45 min |
| 28–32 | MATLAB e exercício resolvido de construção | 20 min |
| — | Intervalo | 10 min |
| 33–37 | Polos, regiões de desempenho, dominância e procedimento de projeto | 20 min |
| 38–44 | Faixa de ganhos, seleção, resposta completa, erro de rampa e MATLAB | 35 min |
| — | Intervalo | 10 min |
| 45–53 | Efeito de zero e polo, deficiência de ângulo, avanço, polos completos, saída e comando | 45 min |
| 54–57 | Conexões, atividade de projeto e síntese | 20 min |

Os tempos incluem as atividades. O exemplo completo de construção é
`1/[s(s+2)(s+4)]`; os outros traçados ajudam a explicar conceitos ou entram
como exercício. Se houver discussão longa, abreviar a demonstração da varredura
de ganhos (29) e o detalhamento do exemplo com zero (16), preservando o bloco
de projeto e a verificação do comando.

## Fontes e exemplos

- MVO-20/2026: `2026/slides/aula24_17-11` e `aula25_17-11`.
- AS-765/2025: `material/slides/cap10`, em especial introdução, regras,
  polos/resposta, projeto e compensadores; capítulo 10 da apostila.

O ganho de projeto `K=10,7` para `1/[s(s+2)(s+6)]` vem do exemplo de 2025.
Adota-se a versão revisada de MVO-20: requisitos temporais de sobressinal até
10% e acomodação a 2% até 5,5 s; região inicial com `zeta>=0,6` e
`-Re(p)>=4/5,5`. O amortecimento calculado é aproximadamente 0,6246125;
não se repete a antiga afirmação de que ele satisfaria estritamente 0,625.

O exemplo de avanço segue o projeto revisado, sem cancelamento de polos:

- planta: `P=1/[s(s+2)]`;
- alvo: `-2 +/- 2j`;
- controlador: `C=16(s+3)/(s+8)`;
- polinômio fechado: `(s+6)(s^2+4s+8)`;
- resposta completa: sobressinal de aproximadamente 8,25%, acomodação de 1,99 s;
- comando inicial ao degrau: 16 no modelo sem saturação.

Acréscimos de 06/11, sincronizados com MVO-20: ângulo de partida
(`1/[s(s²+4s+8)]`, partida −45°, 0<K<32), faixa de ganhos do exemplo 1
(4,88≲K≲11,35), efeito de zero/polo no LGR e atividade com outra planta:
`P=1/[s(s+1)]`, `C=20(s+2)/(s+8)`, polos (s+5)(s²+4s+8), sobressinal de 16,4%
(3,3% com pré-filtro 2/(s+2)).

## Convenções

- Realimentação negativa; `L=K L0`, ganho externo real não negativo.
- Nas regras, modelos estritamente próprios, coeficientes reais e numerador e
  denominador coprimos. O ganho fixo do numerador entra na condição de módulo.
- O limite `K=0` é interpretado por `K -> 0+`; cancelamentos não substituem a
  análise da estabilidade interna.
- A condição de ângulo precede o cálculo do ganho. Conferir todos os polos.
- Fórmulas canônicas de segunda ordem orientam o projeto. Zeros, resíduos e
  polos adicionais entram na validação da resposta completa.
- A ausência do alvo no LGR demonstra que aquele ponto não pode ser obtido só
  com ganho; não é usada como prova de impossibilidade de toda especificação temporal.

## Arquivos e reprodução

- `slides_11_lugar_raizes.pdf`: apresentação final.
- `slides_11_lugar_raizes.tex` e `section*.tex`: conteúdo editável.
- `estilo_lgr.tex`: configurações dos gráficos e marcadores, preservadas de MVO-20.
- `Figuras/`: imagens da capa e tabelas dos dez lugares das raízes e duas respostas.
- `matlab/aula09_cap10.m`: entrada das demonstrações.
- `matlab/demo_fundamentos.m` e `demo_projeto.m`: exemplos comuns aos dois cursos.
- `matlab/validar_dados.m`: comparação das tabelas com os modelos.
- `matlab/gerar_fundamentos.m` e `gerar_projeto.m`: regeneração dos dados.

Na pasta deste conjunto:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error slides_11_lugar_raizes.tex
```

No MATLAB com Control System Toolbox, a partir de `matlab`:

```matlab
aula09_cap10('fundamentos')
aula09_cap10('projeto')
aula09_cap10('todos')    % demonstracoes e conferencias
% Para regenerar as tabelas:
aula09_cap10('dados')
```

Durante a aula, use os blocos separadamente. Cada demonstração fecha as figuras
anteriores. `rlocfind` é opcional; os ganhos usados nas conferências são
reproduzíveis sem seleção interativa. Os dados já acompanham os fontes e a
compilação não depende do MATLAB. Não é necessário Symbolic Math Toolbox.

O pacote `material_aula_10-11_as765.zip` inclui o PDF, os fontes e o estilo
compartilhado `estilo_as765.tex`, com a estrutura de pastas pronta para compilar.

## Referências técnicas

- Ogata, *Engenharia de Controle Moderno*, capítulo de lugar das raízes.
- [Lundberg, MIT: The Root Locus Rules](https://web.mit.edu/people/klund/weblatex/node8.html).
- [MathWorks: rlocus](https://www.mathworks.com/help/control/ref/dynamicsystem.rlocus.html).
- [MathWorks: damp](https://www.mathworks.com/help/control/ref/dynamicsystem.damp.html).
- [MathWorks: stepinfo](https://www.mathworks.com/help/control/ref/dynamicsystem.stepinfo.html).

Material preparado localmente; sem publicação no site nesta etapa.
