function aula08_cap09(bloco)
% AS-765 2026 - 09/11 - Controladores P, PI, PD e PID.
% Use 'acoes', 'projeto', 'pratica' ou 'todos' (padrao).
% Requer Control System Toolbox; execute a partir da pasta deste arquivo.
if nargin==0, bloco='todos'; end
switch lower(char(bloco))
 case 'acoes', demo_acoes;
 case 'projeto', demo_projeto;
 case 'pratica', demo_pratica;
 case 'todos', demo_acoes; demo_projeto; demo_pratica;
 otherwise, error('Bloco desconhecido: use acoes, projeto, pratica ou todos.');
end
fprintf('AS-765: verificacoes do bloco %s concluidas.\n',char(bloco));
end
