function demo_projeto
% AS-765 2026 - Aula de 09/11. Adaptado do MVO-20/2026.
%% Aula 22 - Projeto e sintonia de PI/PID (03/11/2026)
% Modelos simplificados, alocacao de polos e Ziegler-Nichols.
close all; clc;
pasta=fileparts(fileparts(mfilename('fullpath'))); s=tf('s');

%% Aproximacao por ganho DC
P=10/(s^2+2*s+10);
figure; hold on;
for tau=[5 1]
    Ki=1/tau; T=feedback(Ki/s*P,1); Tr=1/(tau*s+1);
    [y,t]=step(T,0:0.01:20); plot(t,y,'LineWidth',1.5);
    conferir(pasta,'modelo.dat',sprintf('full%d',tau),T);
    conferir(pasta,'modelo.dat',sprintf('red%d',tau),Tr);
end
grid on; xlabel('t [s]'); ylabel('Saida'); legend('Completo: tau=5','Completo: tau=1');
assert(~isstable(feedback(10/s*P,1)));

%% Projeto PI: polos repetidos, zero e pre-filtro
P1=1/(s+1); Cpi=pid(3,4); Tpi=feedback(Cpi*P1,1);
F=4/(3*s+4); Tf=minreal(F*Tpi);
figure; step(Tpi,Tf); grid on; legend('PI','PI + pre-filtro');
conferir(pasta,'pi_projeto.dat','pi',Tpi);
conferir(pasta,'pi_projeto.dat','filtro',Tf);
fprintf('Sobressinal PI sem pre-filtro: %.4f %% (analitico: 50*exp(-3))\n',100*(stepinfo(Tpi).Peak-1));
a=0.0101; b=1.3203; zeta=0.8; wc=0.2;
fprintf('Carro: Kp=%.7f; Ki=%.7f\n',(2*zeta*wc-a)/b,wc^2/b);

%% Projeto PID ideal: comparacao com o mesmo denominador sem zeros
P2=1/(s+1)^2; Ci=pid(11,16,4);
Ti=feedback(Ci*P2,1); Tsem=16/(s^3+6*s^2+12*s+16);
assert(isstable(Ti));
figure; step(Ti,Tsem); grid on; legend('PID ideal','Mesmo denominador sem zeros');
conferir(pasta,'pid_projeto.dat','ideal',Ti);
conferir(pasta,'pid_projeto.dat','semzeros',Tsem);
assert(~isproper(feedback(Ci,P2))); % Comando com impulso: nao chamar step(U).
disp('Polos do PID ideal:'); disp(pole(Ti));
disp('Zeros do PID ideal:'); disp(zero(Ti));
fprintf('Sobressinal PID ideal: %.2f %%\n',stepinfo(Ti).Overshoot);

%% Ziegler-Nichols: ganho critico
P3=1/((s+1)*(s+2)*(s+3)); Ku=60; Tu=2*pi/sqrt(11);
Cznpi=pid(0.45*Ku,0.45*Ku/(Tu/1.2));
Cznpid=pid(0.6*Ku,0.6*Ku/(Tu/2),0.6*Ku*Tu/8);
Cs={pid(0.5*Ku),Cznpi,Cznpid};
Ts={feedback(Cs{1}*P3,1),feedback(Cs{2}*P3,1),feedback(Cs{3}*P3,1)};
nomes={'p','pi','pid'};
for k=1:3
    assert(isstable(Ts{k})); conferir(pasta,'zn.dat',nomes{k},Ts{k});
end
figure; step(Ts{:},20); grid on; legend('P ZN (Kp=30)','PI ZN','PID ZN ideal');
for k=1:3
    [~,Pm]=margin(Cs{k}*P3); info=stepinfo(Ts{k});
    fprintf('%s: MF=%.1f graus, pico=%.3f\n',nomes{k},Pm,info.Peak);
end
figure; margin(Cznpid*P3);
assert(~isproper(feedback(Cznpid,P3))); % Impulso de comando no degrau ideal.
fprintf('ZN: Tu=%.6f; Kp=%.6f; Ki=%.6f; Kd=%.6f\n',Tu,Cznpid.Kp,Cznpid.Ki,Cznpid.Kd);

%% Ziegler-Nichols pelo degrau: planta 1/(s+1)^4 e tangente na inflexao
P4=1/(s+1)^4; t3=3; y3=1-13*exp(-3); sl=4.5*exp(-3);
L=t3-y3/sl; Tp=t3+(1-y3)/sl-L; K=dcgain(P4);
kp=1.2*Tp/(K*L); ti=2*L; td=0.5*L;
fprintf('ZN degrau: L=%.3f; T=%.3f; Kp=%.3f; Ti=%.3f; Td=%.3f\n',L,Tp,kp,ti,td);
Czn=pid(kp,kp/ti,kp*td); Caj=pid(kp/2,kp/2/4,kp/2*td);
Tzn=feedback(Czn*P4,1); Taj=feedback(Caj*P4,1);
conferir(pasta,'zn_degrau.dat','zn',Tzn); conferir(pasta,'zn_degrau.dat','ajuste',Taj);
figure; step(Tzn,Taj,30); grid on; legend('ZN','Ajuste fino');
figure; margin(Czn*P4); figure; margin(Caj*P4);
fprintf('AS-765 / projeto: modelos e graficos temporais conferidos.\n');

end

function conferir(pasta,arquivo,coluna,T)
    dados=readtable(fullfile(pasta,'Figuras','projeto',arquivo),'FileType','text');
    y=step(T,dados.t); erro=max(abs(y(:)-dados.(coluna)));
    assert(erro<1e-5,'Divergencia nos dados: %s / %s',arquivo,coluna);
end
