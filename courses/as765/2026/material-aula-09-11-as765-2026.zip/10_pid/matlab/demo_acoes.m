function demo_acoes
% AS-765 2026 - Aula de 09/11. Adaptado do MVO-20/2026.
%% Aula 21 - Acoes P, PI, PD e PID (30/10/2026)
% Base didatica: AS-765, capitulo 9, 2025. Control System Toolbox.
close all; clc;
pasta = fileparts(fileparts(mfilename('fullpath')));
s = tf('s'); P = 1/(s+1);

%% Acao proporcional
ks = [1 4 9]; nomes = {'k1','k4','k9'};
figure; hold on;
for k = 1:3
    T = feedback(ks(k)*P,1);
    [y,t] = step(T,0:0.01:3); plot(t,y,'LineWidth',1.5);
    conferir(pasta,'proporcional.dat',nomes{k},T);
end
grid on; xlabel('t [s]'); ylabel('Saida'); legend('Kp=1','Kp=4','Kp=9');

%% Acao integral
kis = [0.5 2 8]; nomes = {'i05','i2','i8'};
figure; hold on;
for k = 1:3
    C = pid(2,kis(k)); T = feedback(C*P,1);
    assert(isstable(T)); assert(abs(dcgain(T)-1)<1e-10);
    [y,t] = step(T,0:0.01:12); plot(t,y,'LineWidth',1.5);
    conferir(pasta,'integral.dat',nomes{k},T);
end
grid on; xlabel('t [s]'); ylabel('Saida'); legend('Ki=0.5','Ki=2','Ki=8');

%% Perturbacao somada a entrada da planta
Gdp = feedback(P,2); Gdpi = feedback(P,pid(2,2));
figure; step(Gdp,Gdpi); grid on; legend('P','PI');
conferir(pasta,'disturbio.dat','p',Gdp);
conferir(pasta,'disturbio.dat','pi',Gdpi);

%% PD ideal: transferencia de saida propria, comando ideal impulsivo
P2 = 1/(s^2+0.4*s+1); kds = [0 0.8 2.4]; nomes = {'d0','d08','d24'};
figure; hold on;
for k = 1:3
    T = feedback((3+kds(k)*s)*P2,1);
    [y,t] = step(T,0:0.01:10); plot(t,y,'LineWidth',1.5);
    conferir(pasta,'derivativa.dat',nomes{k},T);
end
grid on; xlabel('t [s]'); ylabel('Saida'); legend('Kd=0','Kd=0.8','Kd=2.4');

%% Controladores ideais e margens: nao simular o degrau do comando PD
Cp=pid(2); Cpi=pid(2,2); Cpd=pid(2,0,0.5);
figure; bode(Cp,Cpi,Cpd,{0.01,100}); grid on; legend('P','PI','PD ideal');
B=readtable(fullfile(pasta,'Figuras','acoes','bode.dat'),'FileType','text');
H=squeeze(freqresp(Cpd,B.w));
assert(max(abs(20*log10(abs(H))-B.pd))<1e-7);
assert(max(abs(angle(H)*180/pi-B.fpd))<1e-7);
figure; margin(Cpi*P);
Tpid=feedback(pid(3,2,1)/((s+1)^2),1);
assert(isstable(Tpid)); disp('Polos do exemplo PID:'); disp(pole(Tpid));

%% Retomada da planta de tres polos da aula 20
P3=1/((s+1)*(s+2)*(s+3));
Cs={pid(20),pid(20,4),pid(20,0,6),pid(20,4,6)}; nomes={'p','pi','pd','pid'};
figure; hold on;
for k=1:4
    T=feedback(Cs{k}*P3,1); assert(isstable(T));
    [y,t]=step(T,0:0.01:15); plot(t,y,'LineWidth',1.5);
    conferir(pasta,'planta3.dat',nomes{k},T);
    [Gm,Pm,~,Wcp]=margin(Cs{k}*P3);
    fprintf('%-3s: wgc=%.3f MF=%.2f MG=%.2f dB\n',nomes{k},Wcp,Pm,20*log10(Gm));
end
grid on; xlabel('t [s]'); ylabel('Saida'); legend('P','PI','PD','PID');

%% Feedforward de referencia
C=2; F=1;
Tff=minreal(P*(C+F)/(1+P*C));
assert(abs(dcgain(Tff)-1)<1e-10);
Preal=0.8/(s+1); Treal=minreal(Preal*(C+F)/(1+Preal*C));
fprintf('Ganho DC com erro de modelo: %.6f\n',dcgain(Treal));
fprintf('AS-765 / acoes: todos os graficos temporais conferidos.\n');

end

function conferir(pasta,arquivo,coluna,T)
    dados=readtable(fullfile(pasta,'Figuras','acoes',arquivo),'FileType','text');
    y=step(T,dados.t); erro=max(abs(y(:)-dados.(coluna)));
    assert(erro<1e-5,'Divergencia nos dados: %s / %s',arquivo,coluna);
end
