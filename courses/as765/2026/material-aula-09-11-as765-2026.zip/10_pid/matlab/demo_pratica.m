function demo_pratica
% AS-765 2026 - Aula de 09/11. Adaptado do MVO-20/2026.
%% Aula 23 - Saturacao, anti-windup e derivada filtrada (06/11/2026)
% Controle de velocidade de um veiculo. Estados: velocidade e xI em unidades de comando.
% Ensaio: rampa de 8 graus entre 5 e 25 s (equilibrio inalcancavel com u<=1).
close all; clc;
pasta=fileparts(fileparts(mfilename('fullpath')));
modos={'no','bc','cond'}; resultados=cell(1,3);
for k=1:3
    resultados{k}=simularCarro(modos{k},0.002);
end
nomes={'Sem AW','Back-calculation','Condicional'};
campos=[2 3 4 5]; titulos={'Velocidade [m/s]','Comando solicitado','Tracao aplicada','Estado integral'};
for j=1:4
    figure; hold on;
    for k=1:3
        D=resultados{k}; plot(D(:,1),D(:,campos(j)),'LineWidth',1.4);
    end
    grid on; xlabel('t [s]'); ylabel(titulos{j}); legend(nomes);
end
%% Conferencia dos dados dos slides e convergencia temporal
dados=readtable(fullfile(pasta,'Figuras','pratica','carro.dat'),'FileType','text');
cols={{'vno','cno','uno','ino'},{'vbc','cbc','ubc','ibc'},{'vcond','ccond','ucond','icond'}};
for k=1:3
    D=resultados{k};
    assert(all(D(:,4)>=0 & D(:,4)<=1));
    for j=1:4
        y=interp1(D(:,1),D(:,j+1),dados.t);
        assert(max(abs(y-dados.(cols{k}{j})))<0.003);
    end
    fino=simularCarro(modos{k},0.001);
    vf=interp1(fino(:,1),fino(:,2),D(:,1));
    assert(max(abs(vf-D(:,2)))<0.003);
    fprintf('%s: vmin=%.4f, vmax=%.4f, comando maximo=%.4f\n',nomes{k},min(D(:,2)),max(D(:,2)),max(D(:,3)));
end
%% Equilibrio nas duas rampas
for graus=[6 8]
    ueq=0.1616+9.8*(graus*pi/180)/1.3203;
    fprintf('Rampa de %g graus: ueq=%.6f\n',graus,ueq);
end
%% Filtro derivativo: comparacao em frequencia
s=tf('s'); Kd=0.2; Tf=0.05;
Dideal=Kd*s; Df=Kd*s/(1+Tf*s);
figure; bode(Dideal,Df,{0.1,1e4}); grid on; legend('Ideal','Filtrado');
% Teste numerico das tabelas do Bode:
B=readtable(fullfile(pasta,'Figuras','pratica','filtro.dat'),'FileType','text');
H=squeeze(freqresp(Df,B.w));
assert(max(abs(20*log10(abs(H))-B.filtrado))<1e-7);
%% Projeto da aula 22: efeito do filtro na malha completa
P2=1/(s+1)^2; Ci=pid(11,16,4); Cf=pid(11,16,4,0.05);
Ti=feedback(Ci*P2,1); Tfil=feedback(Cf*P2,1);
conferir(pasta,'pid_projeto.dat','ideal',Ti);
conferir(pasta,'pid_projeto.dat','filtrado',Tfil);
figure; step(Ti,Tfil,8); grid on; legend('PID ideal','PID com Tf=0.05');
for tf_valor=[0 0.02 0.05 0.2]
    C=pid(11,16,4,tf_valor); Y=feedback(C*P2,1);
    assert(isstable(Y)); [~,pm,~,wc]=margin(C*P2);
    fprintf('Tf=%.2f: MF=%.2f, wgc=%.3f, Mp=%.2f %%\n',tf_valor,pm,wc,stepinfo(Y).Overshoot);
end
% Equivalencia das convencoes paralela e por tempos.
Cstd=pidstd(11,11/16,4/11,(4/11)/0.05);
w=logspace(-2,4,100);
assert(max(abs(squeeze(freqresp(Cstd-Cf,w))))<1e-8);
% Zero do PD completo, distinto do zero na origem do ramo D.
Cpd=pid(2,0,0.5,0.05);
assert(abs(zero(Cpd)+10/3)<1e-10);

%% Ruido: regime senoidal sem transitorio de inicializacao
N=readtable(fullfile(pasta,'Figuras','pratica','ruido.dat'),'FileType','text');
t=N.t; m=sin(t)+0.02*sin(100*t);
H1=evalfr(Df,1i); H100=evalfr(Df,100i);
yf=abs(H1)*sin(t+angle(H1))+0.02*abs(H100)*sin(100*t+angle(H100));
yi=Kd*cos(t)+Kd*0.02*100*cos(100*t);
assert(max(abs(yf-N.filtrado))<1e-8);
figure; plot(t,yi,t,yf,t,Kd*cos(t),'LineWidth',1.2); grid on;
xlabel('t [s]'); ylabel('Saida do ramo derivativo'); legend('Ideal com ruido','Filtrado com ruido','Ideal sem ruido');
fprintf('Amplitude da componente de ruido filtrada: %.6f\n',0.02*abs(H100));
%% Derivative kick: PID da aula 22 em P=1/(s+1)^2
s=tf('s'); P2=1/(s+1)^2; Cpid=pid(11,16,4,0.05); Cpi=pid(11,16); Dmed=4*s/(1+0.05*s);
Uerr=feedback(Cpid,P2); Yerr=feedback(Cpid*P2,1);
Umed=Cpi/(1+P2*(Cpi+Dmed)); Ymed=P2*Cpi/(1+P2*(Cpi+Dmed));
conferir(pasta,'kick.dat','uerr',Uerr); conferir(pasta,'kick.dat','umed',Umed);
conferir(pasta,'kick.dat','yerr',Yerr); conferir(pasta,'kick.dat','ymed',Ymed);
figure; subplot(1,2,1); step(Uerr,Umed,1); grid on; legend('D no erro','D na medicao'); title('Comando');
subplot(1,2,2); step(Yerr,Ymed,4); grid on; legend('D no erro','D na medicao'); title('Saida');
fprintf('Sobressinal: D no erro %.1f %%, D na medicao %.1f %%\n',stepinfo(Yerr).Overshoot,stepinfo(minreal(Ymed)).Overshoot);
fprintf('Pratica: saturacao, filtro e derivada na medicao conferidos.\n');

end

function D=simularCarro(modo,h)
    t=(0:h:100)'; X=zeros(length(t),2); X(1,:)=[20 0.1616];
    for i=1:length(t)-1
        x=X(i,:)'; ti=t(i);
        k1=dinamica(ti,x,modo); k2=dinamica(ti+h/2,x+h*k1/2,modo);
        k3=dinamica(ti+h/2,x+h*k2/2,modo); k4=dinamica(ti+h,x+h*k3,modo);
        X(i+1,:)=(x+h*(k1+2*k2+2*k3+k4)/6)';
    end
    v=0.5*(20-X(:,1))+X(:,2); u=min(1,max(0,v));
    D=[t X(:,1) v u X(:,2)];
end
function dx=dinamica(t,x,modo)
    e=20-x(1); v=0.5*e+x(2); u=min(1,max(0,v)); q=0.1*e;
    if strcmp(modo,'bc'), q=q+(u-v)/5; end
    if strcmp(modo,'cond') && ((v>=1 && q>0)||(v<=0 && q<0)), q=0; end
    theta=(8*pi/180)*(t>=5 && t<25);
    dx=[-0.0101*(x(1)-20)+1.3203*(u-0.1616)-9.8*theta; q];
end

function conferir(pasta,arquivo,coluna,T)
    dados=readtable(fullfile(pasta,'Figuras','pratica',arquivo),'FileType','text');
    y=step(T,dados.t); erro=max(abs(y(:)-dados.(coluna)));
    assert(erro<1e-4*max(1,max(abs(y))),'Divergencia nos dados: %s / %s',arquivo,coluna);
end
