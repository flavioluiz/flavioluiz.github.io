from pathlib import Path
import math, cmath

def rk4(f,x,t,h):
 a=f(t,x); b=f(t+h/2,[v+h*w/2 for v,w in zip(x,a)])
 c=f(t+h/2,[v+h*w/2 for v,w in zip(x,b)])
 d=f(t+h,[v+h*w for v,w in zip(x,c)])
 return [v+h*(aa+2*bb+2*cc+dd)/6 for v,aa,bb,cc,dd in zip(x,a,b,c,d)]

def step(num,den,tend=10,dt=.002):
 n=len(den)-1; lead=den[0]; den=[v/lead for v in den];num=[v/lead for v in num]
 num=[0]*(n+1-len(num))+num; D=num[0]; C=list(reversed([num[i]-D*den[i] for i in range(1,n+1)]))
 x=[0.]*n; values=[]
 def f(t,x): return x[1:]+[1-sum(a*b for a,b in zip(reversed(den[1:]),x))]
 for i in range(round(tend/dt)+1):
  t=i*dt;values.append((t,sum(a*b for a,b in zip(C,x))+D));x=rk4(f,x,t,dt)
 return values

def write(name,headers,rows):
 p=Path(__file__).parent/'Figuras'/'pratica';p.mkdir(exist_ok=True)
 with (p/name).open('w') as f:
  f.write(' '.join(headers)+'\n')
  for row in rows: f.write(' '.join(f'{v:.10g}' for v in row)+'\n')

def joinsteps(name,cases,tend=10):
 results=[step(n,d,tend) for _,n,d in cases]
 write(name,['t']+[v[0] for v in cases],[(r[0][0],*[x[1] for x in r]) for r in zip(*results)][::5])

def carro(mode,dt=.002):
 a=.0101;b=1.3203;ue=.1616;kp=.5;ki=.1;tt=5
 x=[20.,ue];out=[]
 def f(t,x):
  e=20-x[0];v=kp*e+x[1];u=max(0,min(1,v)); theta=8*math.pi/180 if 5<=t<25 else 0
  di=ki*e
  if mode=='bc':di+=(u-v)/tt
  if mode=='cond' and ((v>=1 and di>0) or (v<=0 and di<0)):di=0
  return [-a*(x[0]-20)+b*(u-ue)-9.8*theta,di]
 for i in range(round(100/dt)+1):
  t=i*dt;v=kp*(20-x[0])+x[1];out.append((t,x[0],v,max(0,min(1,v)),x[1]));x=rk4(f,x,t,dt)
 return out
runs=[carro(m) for m in ['no','bc','cond']]
write('carro.dat',['t','vno','vbc','vcond','cno','cbc','ccond','uno','ubc','ucond','ino','ibc','icond'],[(r[0][0],*[z[1] for z in r],*[z[2] for z in r],*[z[3] for z in r],*[z[4] for z in r]) for r in zip(*runs)][::25])
for mode,run in zip(['sem AW','back-calculation','condicional'],runs):
 print(mode,'vmin',min(r[1] for r in run),'vmax',max(r[1] for r in run),'vcmax',max(r[2] for r in run))
rows=[]
for i in range(401):
 w=10**(-1+5*i/400);h=.2*1j*w/(1+.05j*w)
 rows.append((w,20*math.log10(.2*w),20*math.log10(abs(h)),90,math.degrees(cmath.phase(h))))
write('filtro.dat',['w','ideal','filtrado','fi','ff'],rows)
rows=[]
# Regime senoidal: sinal de medição m=sin(t)+0.02 sin(100t).
for i in range(2001):
 t=i*.001;h1=.2*1j/(1+.05j);h2=.2*100j/(1+5j)
 rows.append((t,math.sin(t)+.02*math.sin(100*t),.2*math.cos(t)+.4*math.cos(100*t),abs(h1)*math.sin(t+cmath.phase(h1))+.02*abs(h2)*math.sin(100*t+cmath.phase(h2)),.2*math.cos(t)))
write('ruido.dat',['t','m','ideal','filtrado','limpo'],rows[::2])

# Derivative kick: PID da aula 22 (Kp=11, Ki=16, Kd=4, Tf=0,05) em P=1/(s+1)^2.
def polymul(a,b):
 r=[0.]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b): r[i+j]+=x*y
 return r
Dp=[1,2,1]; Den=[.05,1.1,6.6,12.8,16]; Nc=[4.55,11.8,16]; Npi=[.55,11.8,16]
joinsteps('kick.dat',[('uerr',polymul(Nc,Dp),Den),('umed',polymul(Npi,Dp),Den),('yerr',Nc,Den),('ymed',Npi,Den)],4)
for r in runs:
 post=[z for z in r if z[0]>=25]
 print('apos rampa: vmax %.3f em %.1f; vmin %.3f em %.1f'%(max(z[1] for z in post),max(post,key=lambda z:z[1])[0],min(z[1] for z in post),min(post,key=lambda z:z[1])[0]),
       'u=0 de %s a %s'%(next((z[0] for z in post if z[3]<=0),None),max((z[0] for z in post if z[3]<=0),default=None)),
       'u=1 ate %s'%max((z[0] for z in r if z[3]>=1),default=None), 'xI %.3f..%.3f'%(min(z[4] for z in r),max(z[4] for z in r)))

# Comparacao transferida da aula 22: mesmo PID, agora com filtro explicitado.
joinsteps('pid_projeto.dat',[('ideal',[4,11,16],[1,6,12,16]),('filtrado',[4.55,11.8,16],[.05,1.1,6.6,12.8,16])],8)

# PID digital: filtro por Euler implicito, integral por Euler explicito.
# Planta 1/(s+1)^2 com retencao de ordem zero exata; nao ha atraso de calculo.
def digital(h=.005, ruido=.005, limites=(0.,3.)):
 kp,ki,kd,tf,tt=11.,16.,4.,.05,.2
 x1=x2=q=xi=0.; alpha=tf/(tf+h); a=math.exp(-h); out=[]
 for k in range(round(8/h)+1):
  t=k*h; r=1. if t>=1 else 0.; ym=x2+ruido*math.sin(100*t)
  q=alpha*q+(1-alpha)*ym
  ud=-kd/tf*(ym-q); e=r-ym; v=kp*e+xi+ud
  u=max(limites[0],min(limites[1],v))
  out.append((t,r,x2,ym,v,u,xi,ud))
  xi+=h*(ki*e+(u-v)/tt)
  x2=a*x2+h*a*x1+(1-(1+h)*a)*u
  x1=a*x1+(1-a)*u
 return out
write('digital.dat',['t','r','y','ym','v','u','xi','ud'],digital())
