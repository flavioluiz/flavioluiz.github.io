# AS-765 — Aula de 09/11/2026 — Capítulo 9

Apresentação com **69 slides**, para a Aula 8 de AS-765, mantendo o modelo
Beamer de 2026: Darmstadt/beaver, 16:9, capa do E-190 e logotipo do ITA.
O roteiro projetado não contém horários e a apresentação termina com a síntese
e a conexão com lugar das raízes, em 10/11.

## Conteúdo e condução sugerida

| Slides | Conteúdo | Tempo de referência |
|---|---|---:|
| 1–21 | Continuidade de Bode/Nyquist; ações P, I e D; formas paralela e por tempos; erro, perturbação e margens | 55 min |
| 22–33 | Feedforward; projeto PI/PID por coeficientes; zeros, pré-filtro e atividade PI | 50 min |
| — | Intervalo | 10 min |
| 34–42 | Ziegler–Nichols pelo degrau e pelo ganho crítico; validação e ajuste fino | 35 min |
| 43–53 | Saturação, equilíbrio alcançável, windup, back-calculation e integração condicional | 35 min |
| — | Intervalo | 10 min |
| 54–65 | Ruído, filtro derivativo, margens e derivada sobre a medição | 30 min |
| 66–69 | Atividade resolvida, demonstração MATLAB e síntese | 15 min |

Total de referência: quatro horas, incluindo dois intervalos. A atividade de
projeto PI (slide 28) está incluída no segundo bloco. A atividade de saturação
e filtro (slide 66) está incluída no bloco final.

Se a discussão exigir mais tempo, o pré-filtro (27), o detalhamento da sintonia
pelo degrau (37–38) e a distinção entre ramo D e PD completo (57) podem ficar
para leitura posterior. Preservar os dois exercícios, a demonstração do efeito
da saturação e a inclusão do filtro na análise da malha completa.

## Reaproveitamento de MVO-20 de 2026

- Aula 21, 30/10: ações P/PI/PD/PID, gráficos e comparação na planta de três polos.
- Aula 22, 03/11: projeto nominal, atividade PI, pré-filtro, Ziegler–Nichols e validação.
- Aula 23, 06/11: saturação, anti-windup, derivada filtrada e derivada sobre a medição.

Fontes: `2026/slides/aula21_30-10`, `aula22_03-11` e `aula23_06-11`.
O acervo original de AS-765/2025 está em `material/slides/cap9` e no capítulo 9
da apostila. A apresentação de AS-765 consolida os três encontros, remove suas
aberturas e fechamentos repetidos e ajusta as chamadas para a sequência de 2026.

A planta `1/[(s+1)(s+2)(s+3)]` liga a aula à Lista 3. O exemplo
`P=1/(s+1)^2`, com ganhos `(11,16,4)`, reaparece no projeto ideal, na inclusão
do filtro e na comparação entre derivada no erro e na medição. O modelo do
veículo mantém os parâmetros do acervo de AS-765.

## Convenções importantes

- Realimentação negativa unitária e condições iniciais nulas nos modelos LTI,
  salvo indicação explícita no ensaio não linear.
- Forma paralela `Kp + Ki/s + Kd*s`; na forma por tempos,
  `Ki=Kp/Ti` e `Kd=Kp*Td`.
- O PID ideal pode produzir saída regular e comando impulsivo. O filtro é
  incluído explicitamente antes de simular o comando como sinal finito.
- Filtro do ramo D: `Kd*s/(1+Tf*s)`. O ganho assintótico é `Kd/Tf`;
  no PID completo, soma-se `Kp`.
- Anti-windup usa `xI` em unidades de comando:
  `dxI=Ki*e+(u-v)/Tt`. `v` é solicitado; `u` é aplicado.
- Na tabela de Ziegler–Nichols pelo degrau, adota-se `Ti=L/0.3` para PI.
  Há referências que arredondam essa regra para `Ti=3L`; não misturar as convenções.
- As margens com derivada na medição usam `P*(Cpi+Df)`; o numerador de
  referência muda, enquanto o denominador linear é o mesmo.

A implementação digital detalhada de MVO-20 não integra a exposição principal
desta aula. Os exemplos MATLAB locais se concentram nos modelos contínuos.

## Arquivos e reprodução

- `slides_10_pid.pdf`: apresentação final.
- `slides_10_pid.tex`: fonte principal; `section*.tex`: conteúdo editável.
- `Figuras/`: imagens da capa e tabelas numéricas separadas por bloco.
- `gerar_dados.py` e `dados_*.py`: regeneração com biblioteca padrão Python.
- `matlab/aula08_cap09.m`: entrada das demonstrações.
- `matlab/demo_acoes.m`, `demo_projeto.m`, `demo_pratica.m`: exemplos e conferências.

Nesta pasta:

```sh
python3 gerar_dados.py
latexmk -pdf -interaction=nonstopmode -halt-on-error slides_10_pid.tex
```

No MATLAB com Control System Toolbox, a partir da pasta `matlab`:

```matlab
aula08_cap09('acoes')
aula08_cap09('projeto')
aula08_cap09('pratica')
% Para executar todas as conferencias:
aula08_cap09('todos')
```

Use os blocos separadamente durante a aula. Cada demonstração fecha as figuras
anteriores. O bloco de projeto inclui também a aproximação por ganho DC como
material complementar. Não é necessário Simulink ou Symbolic Math Toolbox.
Os dados já acompanham os fontes; a compilação não exige MATLAB.

## Referências técnicas

- [MATLAB: PID na forma paralela e parâmetro Tf](https://www.mathworks.com/help/control/ref/pid.html).
- [MathWorks: back-calculation e integração condicional](https://www.mathworks.com/help/simulink/slref/anti-windup-control-using-a-pid-controller.html).
- [University of Michigan: Ziegler–Nichols pelo ganho crítico](https://eecs.umich.edu/courses/eng100/lec5/ZieglerNichols.html).
- [IIT Bombay: método da curva de reação](https://ee32-iitb.vlabs.ac.in/manual/node34.html), observando a variante de PI indicada acima.

Material preparado localmente; a publicação no site não foi feita nesta etapa.
