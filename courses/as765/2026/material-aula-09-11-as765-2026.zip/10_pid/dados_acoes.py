from pathlib import Path
import math, cmath

def rk4(f,x,t,h):
 a=f(t,x); b=f(t+h/2,[v+h*w/2 for v,w in zip(x,a)])
 c=f(t+h/2,[v+h*w/2 for v,w in zip(x,b)])
 d=f(t+h,[v+h*w for v,w in zip(x,c)])
 return [v+h*(aa+2*bb+2*cc+dd)/6 for v,aa,bb,cc,dd in zip(x,a,b,c,d)]

def step(num,den,tend=10,dt=.002):
 n=len(den)-1; lead=den[0]; den=[v/lead for v in den];num=[v/lead for v in num]
 num=[0]*(n+1-len(num))+num; D=num[0]; C=list(reversed([num[i]-D*den[i] for i in range(1,n+1)]))
 x=[0.]*n; values=[]
 def f(t,x): return x[1:]+[1-sum(a*b for a,b in zip(reversed(den[1:]),x))]
 for i in range(round(tend/dt)+1):
  t=i*dt;values.append((t,sum(a*b for a,b in zip(C,x))+D));x=rk4(f,x,t,dt)
 return values

def write(name,headers,rows):
 p=Path(__file__).parent/'Figuras'/'acoes';p.mkdir(exist_ok=True)
 with (p/name).open('w') as f:
  f.write(' '.join(headers)+'\n')
  for row in rows: f.write(' '.join(f'{v:.10g}' for v in row)+'\n')

def joinsteps(name,cases,tend=10):
 results=[step(n,d,tend) for _,n,d in cases]
 write(name,['t']+[v[0] for v in cases],[(r[0][0],*[x[1] for x in r]) for r in zip(*results)][::5])

joinsteps('proporcional.dat',[(f'k{k}',[k],[1,1+k]) for k in [1,4,9]],3)
joinsteps('integral.dat',[(name,[2,ki],[1,3,ki]) for name,ki in [('i05',.5),('i2',2),('i8',8)]],12)
joinsteps('derivativa.dat',[(name,[kd,3],[1,.4+kd,4]) for name,kd in [('d0',0),('d08',.8),('d24',2.4)]],10)
joinsteps('disturbio.dat',[('p',[1],[1,3]),('pi',[1,0],[1,3,2])],8)
rows=[]
for i in range(401):
 w=10**(-2+4*i/400); s=1j*w
 cs=[2,2+2/s,2+.5*s]
 rows.append((w,*[20*math.log10(abs(c)) for c in cs],*[math.degrees(cmath.phase(c)) for c in cs]))
write('bode.dat',['w','p','pi','pd','fp','fpi','fpd'],rows)
# Planta de tres polos da aula 20: D(s)=s^3+6s^2+11s+6.
joinsteps('planta3.dat',[('p',[20],[1,6,11,26]),('pi',[20,4],[1,6,11,26,4]),('pd',[6,20],[1,6,17,26]),('pid',[6,20,4],[1,6,17,26,4])],15)
