"""Regenera as tabelas dos tres blocos usando apenas a biblioteca padrao."""
from pathlib import Path
import runpy
for nome in ('acoes','projeto','pratica'):
    runpy.run_path(str(Path(__file__).parent/f'dados_{nome}.py'),run_name='__main__')
