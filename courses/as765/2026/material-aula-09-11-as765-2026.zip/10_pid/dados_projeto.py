from pathlib import Path
import math, cmath

def rk4(f,x,t,h):
 a=f(t,x); b=f(t+h/2,[v+h*w/2 for v,w in zip(x,a)])
 c=f(t+h/2,[v+h*w/2 for v,w in zip(x,b)])
 d=f(t+h,[v+h*w for v,w in zip(x,c)])
 return [v+h*(aa+2*bb+2*cc+dd)/6 for v,aa,bb,cc,dd in zip(x,a,b,c,d)]

def step(num,den,tend=10,dt=.002):
 n=len(den)-1; lead=den[0]; den=[v/lead for v in den];num=[v/lead for v in num]
 num=[0]*(n+1-len(num))+num; D=num[0]; C=list(reversed([num[i]-D*den[i] for i in range(1,n+1)]))
 x=[0.]*n; values=[]
 def f(t,x): return x[1:]+[1-sum(a*b for a,b in zip(reversed(den[1:]),x))]
 for i in range(round(tend/dt)+1):
  t=i*dt;values.append((t,sum(a*b for a,b in zip(C,x))+D));x=rk4(f,x,t,dt)
 return values

def write(name,headers,rows):
 p=Path(__file__).parent/'Figuras'/'projeto';p.mkdir(exist_ok=True)
 with (p/name).open('w') as f:
  f.write(' '.join(headers)+'\n')
  for row in rows: f.write(' '.join(f'{v:.10g}' for v in row)+'\n')

def joinsteps(name,cases,tend=10):
 results=[step(n,d,tend) for _,n,d in cases]
 write(name,['t']+[v[0] for v in cases],[(r[0][0],*[x[1] for x in r]) for r in zip(*results)][::5])

joinsteps('modelo.dat',[('red5',[.2],[1,.2]),('full5',[2],[1,2,10,2]),('red1',[1],[1,1]),('full1',[10],[1,2,10,10])],20)
joinsteps('pi_projeto.dat',[('pi',[3,4],[1,4,4]),('filtro',[4],[1,4,4])],5)
joinsteps('pid_projeto.dat',[('ideal',[4,11,16],[1,6,12,16]),('semzeros',[16],[1,6,12,16])],8)
Pu=2*math.pi/math.sqrt(11);kp=36;ki=kp/(Pu/2);kd=kp*Pu/8
# PID ideal: denominador de malha fechada s*D(s) + Kd*s^2 + Kp*s + Ki.
joinsteps('zn.dat',[('p',[30],[1,6,11,36]),('pi',[27,27/(Pu/1.2)],[1,6,11,33,27/(Pu/1.2)]),('pid',[kd,kp,ki],[1,6,11+kd,6+kp,ki])],20)
# Metodo do degrau: planta 1/(s+1)^4, tangente no ponto de inflexao t=3.
y3=1-13*math.exp(-3); sl=4.5*math.exp(-3)
def y4(t): return 1-math.exp(-t)*(1+t+t*t/2+t**3/6)
write('degrau.dat',['t','y','tangente'],[(i*.05,y4(i*.05),y3+sl*(i*.05-3)) for i in range(241)])
Lzn=3-y3/sl; Tzn=(3+(1-y3)/sl)-Lzn
def pidcl(kp,ki,kd,dp):
 nc=[kd,kp,ki]; den=dp+[0]
 den=[d+n for d,n in zip(den,[0]*(len(den)-3)+nc)]
 return nc,den
D4=[1,4,6,4,1]; kz=1.2*Tzn/Lzn
joinsteps('zn_degrau.dat',[('zn',*pidcl(kz,kz/(2*Lzn),kz*.5*Lzn,D4)),('ajuste',*pidcl(kz/2,kz/2/4,kz/2*.5*Lzn,D4))],30)
