# AS-765 — Aula de 16/11/2026 — Capítulo 11

Apresentação com **54 slides**, para a Aula 10 de AS-765: projeto no domínio da
frequência. Mantém o formato Beamer de 2026, em 16:9, com capa E-190/ITA,
roteiro projetado sem horários e atividades resolvidas. Não inclui revisão
para a prova nem um slide final de referências.

## Roteiro sugerido para quatro horas

| Slides | Conteúdo | Tempo de referência |
|---|---|---:|
| 1–8 | Abertura, arquitetura, quatro mapas, identidade S+T e margem de fase | 30 min |
| 9–14 | Banda, cancelamento instável, sensibilidade e atividade | 30 min |
| 15–21 | Pré-filtro, esforço de controle, especificações e loop shaping | 25 min |
| — | Intervalo | 10 min |
| 22–32 | Avanço: normalização, projeto da aeronave, margens, saída e comando | 45 min |
| 33–40 | Atraso: erro de rampa, perda de fase, transitório e atividade | 35 min |
| — | Intervalo | 10 min |
| 41–50 | Atrasos, zero instável, integral de Bode, robustez e atividade | 35 min |
| 51–54 | Demonstrações MATLAB, critérios de aceitação e síntese | 20 min |

Os tempos incluem discussão e exercícios. As demonstrações podem ser
executadas junto aos blocos correspondentes. Se for necessário abreviar,
tratar o pré-filtro como retomada da aula de PID e deixar as restrições de
interpolação (43) e o contraexemplo de grau relativo 1 (47) para leitura.
Preservar a comparação avanço/atraso e as verificações de comando.

## Aproveitamento de AS-765/2025

A organização parte dos conjuntos `material/slides/cap11` e `cap11_red`, do
capítulo 11 da apostila e dos códigos em `material/figuras/cap11`. Mantém os
assuntos centrais e o exemplo de aeronave, com figuras recalculadas e revisão
conceitual. Os arquivos de 2025 foram preservados.

A sequência começa pelos mapas S, T, PS e CS; separa a função do pré-filtro
da função da realimentação; traduz objetivos em especificações; desenvolve
um único projeto de avanço e atraso; e termina com suas limitações.
As conexões com as aulas de PID (09/11) e LGR (10/11) evitam reapresentar
longamente os fundamentos já discutidos.

## Correções e escolhas didáticas

- A notação distingue saída física `y`, medição `y+n` e perturbação `d` na
  entrada da planta. Os mapas de carga e ruído são derivados dessa arquitetura.
- A estabilidade interna exige examinar os quatro mapas. O cancelamento de
  um polo em +1 falha mesmo no modelo exato; o mapa PS revela a instabilidade.
- A identidade S+T=1 é complexa. No cruzamento, os módulos dependem da MF;
  não valem sempre 0,707. Banda de T e cruzamento de L são distintos.
- O pré-filtro é explicitamente colocado antes do comparador. A mudança da
  planta para 0,8P altera o transitório; o integrador ainda elimina o erro ao
  degrau nos modelos estáveis. O comando inicial nominal sobe de 0,6 para 8.
- Todos os compensadores usam `Kh*(s+z)/(s+p)`, com ganho DC `Kh*z/p` e
  ganho de alta frequência `Kh`. Na forma em constantes de tempo, o fator
  `z/p` é mantido. Isso elimina a ambiguidade de normalização do atraso.
- No modelo da aeronave, a fase da planta em 4 rad/s é exatamente -180°.
  Ganho puro 16 situa a malha na fronteira, com polos em -10 e +/-4j.
- O avanço necessário para MF de 60° é de 60°, com alpha=0,07179677.
  As posições são `z=wc*sqrt(alpha)` e `p=wc/sqrt(alpha)`. A margem de ganho
  compensada é finita, aproximadamente 14,75 dB.
- O atraso é normalizado para conservar exatamente o módulo no cruzamento.
  Sua perda de fase e seu efeito na acomodação são apresentados, sem afirmar
  que o transitório permaneça inalterado.
- Relações aproximadas entre MF, amortecimento e sobressinal não são usadas
  como garantia para um sistema de ordem superior. Os índices vêm da resposta
  completa; acomodação usa a faixa de 2%.
- A integral de Bode usa polos instáveis da malha, não zeros. As hipóteses
  são declaradas e o exemplo usa três malhas fechadas estáveis, com grau
  relativo 3. O gráfico de áreas usa frequência linear e logaritmo natural.
- O exemplo com zero em +2 preserva o módulo mas altera a fase, deixando
  dois polos fechados instáveis com o mesmo compensador nominal.
- A condição de pequeno ganho para incerteza multiplicativa é apresentada
  como suficiente; sua violação não significa que toda planta seja instável.

## Projeto nominal da aeronave

```text
P(s) = 10/[s(s+2)(s+8)]
Cav(s) = 59,71281292 (s+1,07179677)/(s+14,92820323)
H(s) = (s+0,4)/(s+0,04)
a = 0,9950869408
C(s) = a Cav(s) H(s)
```

| Índice | Avanço | Avanço + atraso |
|---|---:|---:|
| Cruzamento (rad/s) | 4 | 4 |
| MF (graus) | 60 | 54,86 |
| MG (dB) | 14,75 | 14,24 |
| Kv | 2,67949 | 26,66327 |
| Erro à rampa unitária | 0,373205 | 0,037505 |
| Sobressinal ao degrau | 4,87% | 13,72% |
| Acomodação a 2% | 2,49 s | 5,63 s |
| Comando inicial ao degrau | 59,71 | 59,42 |

Os quatro mapas são estáveis em ambos os projetos. O ganho 4 é uma referência
estável para comparação temporal. Não se usa o ganho marginal 16 para
calcular índices de acomodação. Modelo sem saturação; valores de comando
precisam ser confrontados com a escala e os limites do atuador real.

## Arquivos e reprodução

- `slides_12_projeto_frequencia.pdf`: apresentação.
- `slides_12_projeto_frequencia.tex`, `section*.tex`: conteúdo editável.
- `estilo_frequencia.tex`: configurações dos gráficos.
- `Figuras/`: capa e dez tabelas numéricas dos gráficos.
- `matlab/modelos_cap11.m`: modelos e controladores usados em todo o material.
- `matlab/gerar_dados.m`: regenera as tabelas.
- `matlab/validar_cap11.m`: confere estabilidade, margens, normalizações,
  identidade no cruzamento, pré-filtro e limitações.
- `matlab/aula10_cap11.m`: demonstrações para a aula.

Compilar na pasta deste conjunto:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error slides_12_projeto_frequencia.tex
```

No MATLAB com Control System Toolbox, adicionar a subpasta `matlab` ao path:

```matlab
aula10_cap11('sensibilidade')
aula10_cap11('referencia')
aula10_cap11('projeto')
aula10_cap11('limites')
aula10_cap11('todos')  % demonstrações e conferências
% Regenerar as tabelas:
aula10_cap11('dados')
```

Os dados já acompanham os fontes; a compilação não depende do MATLAB. As
demonstrações não exigem Symbolic Math Toolbox. A verificação do cancelamento
usa `minreal` apenas em cada mapa individual, depois de construir a conexão;
isso não equivale a reduzir o produto PC antes de analisar a estabilidade.

O pacote `material_aula_16-11_as765.zip` inclui PDF, fontes, figuras, MATLAB e
estilo compartilhado, mantendo a estrutura de pastas para compilar.

## Referências técnicas

- AS-765/2025: capítulo 11, slides completos e versão reduzida, citados acima.
- Åström e Murray, *Feedback Systems*, análise e projeto no domínio da frequência.
- [K. Tsakalis, notas EEE480/482](https://tsakalis.faculty.asu.edu/notes/fbk_1.pdf),
  sensibilidade, estabilidade, limitações e teorema 1.4.9, p. 18.
- [MIT 6.241J, notas de aula 16](https://ocw.mit.edu/courses/6-241j-dynamic-systems-and-control-spring-2011/resources/mit6_241js11_lec16/).
- [MathWorks: margin](https://www.mathworks.com/help/control/ref/dynamicsystem.margin.html),
  [allmargin](https://www.mathworks.com/help/control/ref/dynamicsystem.allmargin.html) e
  [stepinfo](https://www.mathworks.com/help/control/ref/dynamicsystem.stepinfo.html).

Material preparado localmente; sem publicação no site nesta etapa.
