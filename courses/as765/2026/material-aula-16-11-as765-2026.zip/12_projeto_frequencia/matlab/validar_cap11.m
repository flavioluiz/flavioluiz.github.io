function validar_cap11
M=modelos_cap11; s=M.s; w=logspace(-4,4,2000);
for name={'base','lead','total'}
 R=M.(name{1});
 assert(isstable(R.S) && isstable(R.T) && isstable(R.PS) && isstable(R.CS));
 H=squeeze(freqresp(R.S+R.T,w)); assert(max(abs(H-1))<1e-10);
 fprintf('%s: MF=%.8f; MG=%.8f dB; wgc=%.8f; Ms=%.8f; Mt=%.8f; Kv=%.8f; e_rampa=%.8f; Mp=%.8f; ts=%.8f\n',...
 name{1},R.Pm,20*log10(R.Gm),R.Wgc,R.Ms,R.Mt,R.Kv,1/R.Kv,R.info.Overshoot,R.info.SettlingTime);
end
assert(abs(M.Kg-16)<1e-12);
assert(norm(sort(roots([1 10 16 160]))-sort([-10;4j;-4j]))<1e-9);
assert(abs(abs(evalfr(M.lead.L,4j))-1)<1e-10);
assert(abs(M.lead.Pm-60)<0.02 && abs(M.lead.Wgc-4)<1e-3);
assert(abs(M.total.Wgc-4)<1e-3 && M.total.Pm>50 && 1/M.total.Kv<0.05);
assert(abs(evalfr(M.Clead,0)-M.Kh*M.alpha)<1e-10);
fprintf('Lead: alpha %.10f, z %.10f, p %.10f, Kh %.10f, K0 %.10f\n',M.alpha,M.z,M.p,M.Kh,M.Kh*M.alpha);
fprintf('Lag: a %.10f, ganho DC %.10f; perda fase %.10f graus\n',M.a,10*M.a,60-M.total.Pm);
% Identidade exata no cruzamento, sem aproximacao de segunda ordem.
L=5/(s+1)^3; wc=sqrt(5^(2/3)-1); pm=180-3*atand(wc);
S=feedback(tf(1),L); v=abs(evalfr(S,1j*wc));
assert(abs(v-1/(2*sind(pm/2)))<1e-5);
fprintf('L5: MF %.10f, wgc %.10f; |S(wgc)| %.10f; banda T %.10f\n',pm,wc,v,bandwidth(feedback(L,1)));
% Quatro mapas no cancelamento instavel: minreal apenas para examinar cada mapa.
Ph=1/(s-1); Ch=(s-1)/s;
assert(isstable(minreal(feedback(Ph*Ch,1))));
assert(~isstable(minreal(feedback(Ph,Ch))));
assert(isstable(minreal(feedback(Ch,Ph))));
% Feedforward: realizavel, estavel e equivalente ao modelo desejado nominal.
assert(isstable(M.Fr) && isproper(M.Fr));
assert(norm(minreal(M.Trff-M.Fm),inf)<1e-8);
assert(abs(dcgain(M.Trinc)-1)<1e-8);
Up=ss(M.Uplain); Uf=ss(M.Uff);
fprintf('Feedforward: u(0+) PI %.6f; modelo de referencia %.6f\n',Up.D,Uf.D);
% Integral de Bode: somente malhas estaveis, grau relativo >=2, sem polos no eixo.
for K=[2 5 7.5]
 assert(isstable(feedback(K/(s+1)^3,1)));
 f=@(om) log(abs((1+1j*om).^3./((1+1j*om).^3+K)));
 I=integral(f,0,1000,'Waypoints',[1 1.5 sqrt(3) 2 4],'AbsTol',1e-8);
 assert(abs(I)<2e-6);
 fprintf('Bode K=%g: integral em [0,1000] = %.10g\n',K,I);
end
% Zero RHP preserva modulo, mas o mesmo controlador nao estabiliza esta planta.
A=(1-s/2)/(1+s/2); H=squeeze(freqresp(A,w));
assert(max(abs(abs(H)-1))<1e-10);
Tnm=feedback(M.lead.L*A,1); assert(sum(real(pole(Tnm))>0)==2);
fprintf('Zero RHP em +2: dois polos fechados no SPD com o controlador nominal.\n');
fprintf('Todas as verificacoes do capitulo 11 passaram.\n');
end
