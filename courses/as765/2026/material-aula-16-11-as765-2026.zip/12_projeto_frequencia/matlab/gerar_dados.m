function gerar_dados
% Gera tabelas vetoriais dos modelos declarados; nao altera o acervo de 2025.
M=modelos_cap11; s=M.s;
pasta=fullfile(fileparts(fileparts(mfilename('fullpath'))),'Figuras');
w=logspace(-3,3,650)'; cases={'base','lead','total'};
B=w; labels={'w'};
for k=1:3
 R=M.(cases{k}); H=squeeze(freqresp(R.L,w));
 HS=squeeze(freqresp(R.S,w)); HT=squeeze(freqresp(R.T,w));
 B=[B 20*log10(abs(H)) unwrap(angle(H))*180/pi 20*log10(abs(HS)) 20*log10(abs(HT))]; %#ok<AGROW>
 labels=[labels strcat(cases{k},{'_mag','_fase','_S','_T'})]; %#ok<AGROW>
end
salvar(pasta,'malhas.dat',labels,B);
t=(0:0.005:20)'; D=t; labels={'t'};
for k=1:3
 R=M.(cases{k}); y=step(R.T,t); u=step(R.CS,t);
 D=[D y u]; labels=[labels strcat(cases{k},{'_y','_u'})]; %#ok<AGROW>
end
salvar(pasta,'degraus.dat',labels,D);
t=(0:0.02:120)'; D=t;
for k=2:3
 R=M.(cases{k}); e=lsim(R.S,t,t);
 D=[D e]; %#ok<AGROW>
end
salvar(pasta,'rampa.dat',{'t','lead','total'},D);
% Curvas do controlador: forma em polos/zeros, DC e ganho de alta frequencia.
Cd=(s+1)/(s+10); Ca=(s+1)/(s+0.1);
B=w;
for C={Cd,Ca,M.Clead,M.a*M.Hlag}
 H=squeeze(freqresp(C{1},w)); B=[B 20*log10(abs(H)) unwrap(angle(H))*180/pi]; %#ok<AGROW>
end
salvar(pasta,'compensadores.dat',{'w','lead_mag','lead_fase','lag_mag','lag_fase','projeto_mag','projeto_fase','lagproj_mag','lagproj_fase'},B);
% Relacoes S,T e L: usa valores complexos exatos.
L5=5/(s+1)^3; S5=feedback(tf(1),L5); T5=feedback(L5,1);
B=w;
for C={L5,S5,T5}
 H=squeeze(freqresp(C{1},w)); B=[B 20*log10(abs(H))]; %#ok<AGROW>
end
salvar(pasta,'sensibilidade.dat',{'w','L','S','T'},B);
% Cancelamento instavel: Y/R estavel e Y/D instavel, mesmo no modelo exato.
t=(0:0.01:4)'; salvar(pasta,'cancelamento.dat',{'t','referencia','disturbio'},[t 1-exp(-t) sinh(t)]);
% Feedforward como pre-filtro de referencia; u e comparado no mesmo ensaio.
t=(0:0.01:20)'; y=step(M.Tff,t); yf=step(M.Trff,t);
u=step(M.Uplain,t); uf=step(M.Uff,t); yi=step(M.Trinc,t);
salvar(pasta,'feedforward.dat',{'t','pi','ff','incerto','u_pi','u_ff'},[t y yf yi u uf]);
% Waterbed: todas as malhas fechadas sao estaveis e o grau relativo e 3.
wlin=linspace(0,12,1500)'; wbed=unique([w; linspace(1.2,2.1,1000)']); B=wbed; BL=wlin;
for K=[2 5 7.5]
 R=feedback(tf(1),K/(s+1)^3);
 B=[B 20*log10(abs(squeeze(freqresp(R,wbed))))]; %#ok<AGROW>
 BL=[BL log(abs(squeeze(freqresp(R,wlin))))]; %#ok<AGROW>
end
salvar(pasta,'waterbed.dat',{'w','k2','k5','k75'},B);
salvar(pasta,'waterbed_linear.dat',{'w','k2','k5','k75'},BL);
% Mesmo modulo, fase adicional por zero RHP ou atraso.
B=[w -2*atan(w/2)*180/pi -w*0.1*180/pi];
salvar(pasta,'fase_extra.dat',{'w','zero','atraso'},B);
fprintf('Dados do capitulo 11 gerados.\n');
end
function salvar(pasta,nome,colunas,D)
assert(all(isfinite(D(:))));
f=fopen(fullfile(pasta,nome),'w'); assert(f>=0);
c=onCleanup(@() fclose(f));
fprintf(f,'%s\n',strjoin(colunas,' '));
fmt=[repmat('%.12g ',1,size(D,2)-1) '%.12g\n']; fprintf(f,fmt,D.');
end
