function aula10_cap11(bloco)
% AS-765, 16/11/2026: demonstracoes de projeto em frequencia.
% aula10_cap11('sensibilidade'|'referencia'|'projeto'|'limites'|'todos'|'dados')
if nargin==0, bloco='projeto'; end
if strcmpi(bloco,'dados'), gerar_dados; validar_cap11; return; end
if strcmpi(bloco,'todos')
 for b={'sensibilidade','referencia','projeto','limites'}
  aula10_cap11(b{1});
 end
 validar_cap11; return
end
M=modelos_cap11; s=M.s;
switch lower(bloco)
 case 'sensibilidade'
  L=5/(s+1)^3; S=feedback(tf(1),L); T=feedback(L,1);
  figure('Name','Sensibilidade e complementar'); bodemag(L,S,T,{.01,100});
  grid on; legend('L','S','T');
  figure('Name','Nyquist: distancia ao ponto critico'); nyquist(L); grid on
  Ph=1/(s-1); Ch=(s-1)/s;
  fprintf('Cancelamento: estabilidade de S,T,PS,CS apos reducao individual:\n');
  disp([isstable(minreal(feedback(tf(1),Ph*Ch))) ...
   isstable(minreal(feedback(Ph*Ch,1))) ...
   isstable(minreal(feedback(Ph,Ch))) ...
   isstable(minreal(feedback(Ch,Ph)))]);
  t=(0:.01:4)'; figure('Name','Cancelamento instavel');
  plot(t,1-exp(-t),t,sinh(t),'LineWidth',1.5); grid on
  xlabel('Tempo (s)'); ylabel('Saida'); legend('Degrau em r','Degrau em d');
 case 'referencia'
  t=(0:.01:20)'; figure('Name','Referencia: saida');
  plot(t,step(M.Tff,t),t,step(M.Trff,t),t,step(M.Trinc,t),'LineWidth',1.5);
  grid on; xlabel('Tempo (s)'); ylabel('Saida');
  legend('PI','PI + pre-filtro nominal','Pre-filtro com planta 0.8P');
  figure('Name','Referencia: comando');
  plot(t,step(M.Uplain,t),t,step(M.Uff,t),'LineWidth',1.5);
  grid on; xlabel('Tempo (s)'); ylabel('Comando'); legend('PI','PI + pre-filtro');
 case 'projeto'
  fprintf('Avanco: Kh=%.8f, z=%.8f, p=%.8f\n',M.Kh,M.z,M.p);
  disp('Cav ='); disp(zpk(M.Clead)); disp('Ctotal ='); disp(zpk(M.Ctotal));
  figure('Name','Bode das malhas'); bode(M.base.L,M.lead.L,M.total.L,{.001,1000});
  grid on; legend('C=4','Avanco','Avanco + atraso');
  figure('Name','Margens do projeto final'); margin(M.total.L); grid on
  disp('Todos os cruzamentos do projeto final:'); disp(allmargin(M.total.L));
  t=(0:.005:20)'; figure('Name','Degrau: saida e comando');
  subplot(2,1,1); plot(t,step(M.base.T,t),t,step(M.lead.T,t),...
   t,step(M.total.T,t),'LineWidth',1.5); grid on
  ylabel('Saida'); legend('C=4','Avanco','Avanco + atraso');
  subplot(2,1,2); plot(t,step(M.base.CS,t),t,step(M.lead.CS,t),...
   t,step(M.total.CS,t),'LineWidth',1.5); grid on
  xlabel('Tempo (s)'); ylabel('Comando');
  t=(0:.02:120)'; figure('Name','Erro a rampa');
  plot(t,lsim(M.lead.S,t,t),t,lsim(M.total.S,t,t),'LineWidth',1.5);
  grid on; xlabel('Tempo (s)'); ylabel('Erro'); legend('Avanco','Avanco + atraso');
 case 'limites'
  figure('Name','Integral de Bode: sensibilidade');
  bodemag(feedback(tf(1),2/(s+1)^3),feedback(tf(1),5/(s+1)^3),...
   feedback(tf(1),7.5/(s+1)^3),{.01,100}); grid on
  legend('K=2','K=5','K=7.5');
  A=(1-s/2)/(1+s/2);
  figure('Name','Zero instavel: mesma magnitude, fase diferente');
  bode(M.lead.L,M.lead.L*A,{.01,100}); grid on; legend('Nominal','Zero em +2');
  disp('Polos fechados com o zero em +2:'); disp(pole(feedback(M.lead.L*A,1)));
  fprintf('Atraso 0.1 s: perda de fase no cruzamento = %.4f graus\n',4*.1*180/pi);
 otherwise
  error('Bloco desconhecido. Use sensibilidade, referencia, projeto, limites, todos ou dados.');
end
end
