function M=modelos_cap11
% AS-765, 16/11/2026. Modelos usados em todos os graficos e demonstracoes.
s=tf('s'); M.s=s;
M.P=10/(s*(s+2)*(s+8)); M.wc=4; M.phi=60;
M.Kg=1/abs(evalfr(M.P,1j*M.wc));
M.alpha=(1-sind(M.phi))/(1+sind(M.phi));
M.z=M.wc*sqrt(M.alpha); M.p=M.wc/sqrt(M.alpha);
M.Kh=1/(abs(evalfr(M.P,1j*M.wc))*sqrt(M.alpha));
M.Clead=M.Kh*(s+M.z)/(s+M.p);
M.Hlag=(s+0.4)/(s+0.04); M.a=1/abs(evalfr(M.Hlag,1j*M.wc));
M.Ctotal=M.a*M.Clead*M.Hlag;
M.Cbase=tf(4);
cs={M.Cbase,M.Clead,M.Ctotal}; M.nomes={'base','lead','total'};
for k=1:3
 R.C=cs{k}; R.L=R.C*M.P;
 R.S=feedback(tf(1),R.L); R.T=feedback(R.L,1);
 R.PS=feedback(M.P,R.C); R.CS=feedback(R.C,M.P);
 R.Kv=dcgain(minreal(s*R.L));
 [R.Gm,R.Pm,R.Wpc,R.Wgc]=margin(R.L);
 % O projeto fixa wc=4 exatamente; evitar erro de interpolacao de margin.
 if k>1, R.Wgc=M.wc; R.Pm=180+angle(evalfr(R.L,1j*M.wc))*180/pi; end
 R.info=stepinfo(R.T,'SettlingTimeThreshold',0.02);
 [R.Ms,R.ws]=getPeakGain(R.S); [R.Mt,R.wt]=getPeakGain(R.T);
 M.(M.nomes{k})=R;
end
M.Pff=1/(s+1)^3; M.Cff=0.6+0.5/s;
M.Tff=feedback(M.Cff*M.Pff,1); M.Fm=1/(0.5*s+1)^3;
M.Fr=minreal(M.Fm/M.Tff,1e-8);
M.Trff=minreal(M.Fr*M.Tff,1e-8);
M.Uff=minreal(M.Fm/M.Pff,1e-8);
M.Uplain=feedback(M.Cff,M.Pff);
M.Trinc=minreal(M.Fr*feedback(0.8*M.Pff*M.Cff,1),1e-8);
end
